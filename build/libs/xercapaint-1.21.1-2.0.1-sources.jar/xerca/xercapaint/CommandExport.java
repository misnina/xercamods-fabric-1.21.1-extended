package xerca.xercapaint;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2487;
import net.minecraft.class_2507;
import net.minecraft.class_3222;
import xerca.xercapaint.item.ItemCanvas;
import xerca.xercapaint.item.Items;
import xerca.xercapaint.packets.ExportPaintingPacket;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class CommandExport {
    private CommandExport() {
    }

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                class_2170.method_9247("paintexport")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                                .executes(p -> paintExport(p.getSource(), StringArgumentType.getString(p, "name"))))
        );
    }

    private static int paintExport(class_2168 stack, String name) {
        Mod.LOGGER.debug("Paint export called. name: {}", name);
        if (stack.method_9228() == null) {
            Mod.LOGGER.error("Command entity is not found");
            return 0;
        }
        class_1297 commander = stack.method_9228();
        if (!(commander instanceof class_3222 player)) {
            Mod.LOGGER.error("Command entity is not a player");
            return 0;
        }

        ExportPaintingPacket pack = new ExportPaintingPacket(name);
        ServerPlayNetworking.send(player, pack);
        return 1;
    }

    public static boolean doExport(class_1657 player, String name) {
        String dir = "paintings";
        String filename = name + ".paint";
        String filepath = dir + "/" + filename;
        File directory = new File(dir);
        if (!directory.exists()) {
            try {
                Files.createDirectories(directory.toPath());
            } catch (IOException e) {
                Mod.LOGGER.error("Could not create paintings directory", e);
                return false;
            }
        }

        for (class_1799 s : player.method_5877()) {
            if (s.method_7909() instanceof ItemCanvas itemCanvas) {
                List<Integer> pixels = s.method_57824(Items.CANVAS_PIXELS);
                String canvasId = s.method_57824(Items.CANVAS_ID);
                if (pixels != null && canvasId != null) {
                    try {
                        int version = s.method_57825(Items.CANVAS_VERSION, 1);
                        int generation = s.method_57825(Items.CANVAS_GENERATION, 0);
                        String title = s.method_57824(Items.CANVAS_TITLE);
                        String author = s.method_57824(Items.CANVAS_AUTHOR);

                        class_2487 tag = new class_2487();

                        tag.method_10572("pixels", pixels);
                        tag.method_10567("ct", itemCanvas.getCanvasType().toByte());
                        if (itemCanvas.isGlass()) {
                            tag.method_10556("glass", true);
                        }

                        List<Integer> sidePixels = s.method_57824(Items.CANVAS_SIDE_PIXELS);
                        if (sidePixels != null) {
                            tag.method_10556("sidesActive", s.method_57825(Items.CANVAS_SIDES_ACTIVE, false));
                            tag.method_10539("sidePixels", sidePixels.stream().mapToInt(Integer::intValue).toArray());
                        }
                        if (title != null && author != null) {
                            tag.method_10582("title", title);
                            tag.method_10582("author", author);
                            tag.method_10582("name", canvasId);
                            tag.method_10569("v", version);
                            tag.method_10569("generation", generation);
                        }
                        class_2507.method_10630(tag, Path.of(filepath));
                        return true;
                    } catch (IOException e) {
                        Mod.LOGGER.error("Error while exporting painting", e);
                    }
                }
            }
        }
        return false;
    }
}
