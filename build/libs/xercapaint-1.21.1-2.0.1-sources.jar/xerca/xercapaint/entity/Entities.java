package xerca.xercapaint.entity;

import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import xerca.xercapaint.Mod;

public class Entities {
    private Entities() {
    }

    public static final class_2960 CANVAS_ID = Mod.id("canvas");
    public static final class_2960 EASEL_ID = Mod.id("easel");

    public static final class_1299<EntityCanvas> CANVAS = class_1299.class_1300.<EntityCanvas>method_5903(EntityCanvas::new, class_1311.field_17715)
            .method_17687(0.5f, 0.5f)
            .method_55687(0.25f)
            .method_27300(Integer.MAX_VALUE)
            .method_5905(CANVAS_ID.toString());

    public static final class_1299<EntityEasel> EASEL = class_1299.class_1300.<EntityEasel>method_5903(EntityEasel::new, class_1311.field_17715)
            .method_17687(0.8f, 1.975f)
            .method_55687(1.8f)
            .method_5905(EASEL_ID.toString());

    public static void registerEntities() {
        class_2378.method_10230(class_7923.field_41177, CANVAS_ID, CANVAS);
        class_2378.method_10230(class_7923.field_41177, EASEL_ID, EASEL);
    }
}
