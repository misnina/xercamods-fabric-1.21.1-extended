package xerca.xercapaint.entity;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_5630;
import net.minecraft.class_8103;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import xerca.xercapaint.Mod;
import xerca.xercapaint.item.ItemCanvas;
import xerca.xercapaint.item.ItemPalette;
import xerca.xercapaint.item.Items;
import xerca.xercapaint.packets.CloseGuiPacket;
import xerca.xercapaint.packets.OpenGuiPacket;

import java.util.Objects;


public class EntityEasel extends class_1297 {
    private static final int MAX_PAINTER_DISTANCE_SQR = 64;
    private static final class_2940<class_1799> DATA_CANVAS;
    private @Nullable class_1657 painter;
    private @Nullable Runnable dropDeferred;
    private int dropWaitTicks;

    static {
        DATA_CANVAS = class_2945.method_12791(EntityEasel.class, class_2943.field_13322);
    }

    public EntityEasel(class_1937 world) {
        super(Entities.EASEL, world);
    }

    public EntityEasel(class_1299<EntityEasel> entityCanvasEntityType, class_1937 world) {
        super(entityCanvasEntityType, world);
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof EntityEasel other)) {
            return false;
        }
        return Objects.equals(this.method_5667(), other.method_5667());
    }

    @Override
    public int hashCode() {
        return Objects.hash(EntityEasel.class, this.method_5667());
    }

    @Nullable
    public class_1657 getPainter() {
        return painter;
    }

    public void setPainter(@Nullable class_1657 painter) {
        this.painter = painter;
    }

    @Override
    public boolean method_5810() {
        return false;
    }

    @Override
    public boolean method_5643(class_1282 damageSource, float amount) {
        if (this.method_5679(damageSource)) {
            return false;
        }

        if (!this.method_37908().field_9236 && !this.method_31481()) {
            if (!getItem().method_7960() && !damageSource.method_48789(class_8103.field_42249)) {
                this.dropItem(damageSource.method_5529(), false);
            } else {
                this.dropItem(damageSource.method_5529());
                this.method_5768();
                this.method_5785();
            }
        }
        return false;
    }

    private void showBreakingParticles() {
        if (this.method_37908() instanceof class_3218 serverLevel) {
            serverLevel.method_14199(new class_2388(class_2398.field_11217, class_2246.field_10148.method_9564()), this.method_23317(), this.method_23323(0.6666666666666666D), this.method_23321(), 10, this.method_17681() / 4.0F, this.method_17682() / 4.0F, this.method_17681() / 4.0F, 0.05D);
        }
    }

    @Override
    public void method_5768() {
        showBreakingParticles();
        this.method_5650(class_5529.field_26998);
    }

    @Override
    protected void method_5693(class_2945.@NotNull class_9222 builder) {
        builder.method_56912(DATA_CANVAS, class_1799.field_8037);
    }

    public void dropItem(@Nullable class_1297 entity) {
        this.dropItem(entity, true);
    }

    private void dropItem(@Nullable class_1297 entity, boolean dropSelf) {
        if (painter != null) {
            if (!this.method_37908().field_9236 && dropDeferred == null) {
                if (painter instanceof class_3222 serverPainter) {
                    CloseGuiPacket pack = new CloseGuiPacket();
                    ServerPlayNetworking.send(serverPainter, pack);
                }
                dropDeferred = () -> doDrop(entity, dropSelf);
            }
        } else {
            doDrop(entity, dropSelf);
        }
    }

    public void doDrop(@Nullable class_1297 entity, boolean dropSelf) {
        class_1799 canvasStack = this.getItem();
        this.setItem(class_1799.field_8037);

        if (!canvasStack.method_7960()) {
            canvasStack = canvasStack.method_7972();
            this.method_5775(canvasStack);
        }

        if (entity instanceof class_1657 player && player.method_31549().field_7477) {
            return;
        }

        if (dropSelf && this.method_37908().method_8450().method_8355(class_1928.field_19393)) {
            this.method_5775(this.getEaselItemStack());
        }
    }

    public class_1799 getItem() {
        return this.method_5841().method_12789(DATA_CANVAS);
    }

    public void setItem(class_1799 itemStack) {
        this.setItem(itemStack, true);
    }

    public void setItem(class_1799 itemStack, boolean makeSound) {
        if (!itemStack.method_7960()) {
            itemStack = itemStack.method_7972();
            itemStack.method_7939(1);
            itemStack.method_27320(this);
        }

        this.method_5841().method_12778(DATA_CANVAS, itemStack);
        if (makeSound) {
            if (!itemStack.method_7960()) {
                this.method_5783(class_3417.field_14875, 1.0F, 1.0F);
            } else {
                this.method_5783(class_3417.field_14809, 1.0F, 1.0F);
            }
        }
    }

    @Override
    public class_5630 method_32318(int i) {
        return i == 0 ? new class_5630() {
            @Override
            public class_1799 method_32327() {
                return EntityEasel.this.getItem();
            }

            @Override
            public boolean method_32332(class_1799 itemStack) {
                EntityEasel.this.setItem(itemStack);
                return true;
            }
        } : super.method_32318(i);
    }

    @Override
    public void method_5674(class_2940<?> accessor) {
        super.method_5674(accessor);
        if (accessor.equals(DATA_CANVAS)) {
            class_1799 itemStack = this.getItem();
            if (!itemStack.method_7960() && !this.equals(itemStack.method_27319())) {
                itemStack.method_27320(this);
            }
        }
    }

    @Override
    public void method_5652(class_2487 tag) {
        if (!this.getItem().method_7960()) {
            tag.method_10566("Item", this.getItem().method_57358(this.method_56673()));
        }
    }

    @Override
    public void method_5749(class_2487 tag) {
        class_2487 itemTag = tag.method_10562("Item");
        if (!itemTag.method_33133()) {
            class_1799 itemStack = class_1799.method_57359(this.method_56673(), itemTag);
            if (itemStack.method_7960()) {
                Mod.LOGGER.warn("Unable to load item from: {}", itemTag);
            }
            this.setItem(itemStack, false);
        }
    }

    @Override
    public class_1269 method_5688(class_1657 player, class_1268 hand) {
        class_1799 itemInHand = player.method_5998(hand);
        boolean isEaselFilled = !this.getItem().method_7960();
        boolean handHoldsCanvas = itemInHand.method_7909() instanceof ItemCanvas;
        boolean handHoldsPalette = itemInHand.method_7909() instanceof ItemPalette;
        if (this.method_37908().field_9236) {
            return !isEaselFilled && !handHoldsCanvas ? class_1269.field_5811 : class_1269.field_5812;
        } else {
            if (!isEaselFilled) {
                if (handHoldsCanvas && !this.method_31481()) {
                    this.setItem(itemInHand);
                    itemInHand.method_7934(1);
                }
            } else {
                boolean unused = this.painter == null;
                boolean toEdit = handHoldsPalette && getItem().method_57825(Items.CANVAS_GENERATION, 0) <= 0;
                boolean allowed = unused || !toEdit;
                if (player instanceof class_3222 serverPlayer) {
                    OpenGuiPacket pack = new OpenGuiPacket(this.method_5628(), allowed, toEdit, hand);
                    ServerPlayNetworking.send(serverPlayer, pack);
                }
                if (toEdit && allowed) {
                    this.painter = player;
                }
            }

            return class_1269.field_21466;
        }
    }

    protected class_1799 getEaselItemStack() {
        return new class_1799(Items.ITEM_EASEL);
    }

    @Override
    public class_1799 method_31480() {
        class_1799 canvas = this.getItem();
        return canvas.method_7960() ? this.getEaselItemStack() : canvas.method_7972();
    }

    @Override
    public void method_5773() {
        super.method_5773();
        method_5784(class_1313.field_6308, new class_243(0, -0.25, 0));
        method_23311();
        if (!this.method_37908().field_9236 && dropDeferred != null) {
            dropWaitTicks++;
            if (painter == null || dropWaitTicks > 80) {
                dropDeferred.run();
                dropDeferred = null;
                dropWaitTicks = 0;
            }
        }
        if (painter != null && (painter.method_31481() || !painter.method_5805() || painter.method_5858(this) > MAX_PAINTER_DISTANCE_SQR)) {
            painter = null;
        }
    }

    @Override
    public boolean method_5863() {
        return true;
    }

}
