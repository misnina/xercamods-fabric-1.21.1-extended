package xerca.xercapaint.entity;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1530;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2312;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3231;
import net.minecraft.class_3417;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import xerca.xercapaint.CanvasType;
import xerca.xercapaint.item.ItemCanvas;
import xerca.xercapaint.item.Items;
import xerca.xercapaint.packets.PictureRequestPacket;

import java.util.*;


public class EntityCanvas extends class_1530 {
    @Nullable
    private String canvasTitle;
    @Nullable
    private String canvasAuthor;
    private int canvasGeneration;
    private boolean canvasSigned;
    private int tickCounter1;
    private static final class_2940<String> CANVAS_ID = class_2945.method_12791(EntityCanvas.class, class_2943.field_13326);
    private static final class_2940<Integer> CANVAS_VERSION = class_2945.method_12791(EntityCanvas.class, class_2943.field_13327);
    private static final class_2940<Byte> CANVAS_TYPE_KEY = class_2945.method_12791(EntityCanvas.class, class_2943.field_13319);
    private static final class_2940<Byte> CANVAS_ROTATION = class_2945.method_12791(EntityCanvas.class, class_2943.field_13319);
    private static final class_2940<Boolean> CANVAS_GLASS = class_2945.method_12791(EntityCanvas.class, class_2943.field_13323);
    public static final Map<String, Picture> PICTURES = Maps.newHashMap();
    private static final Set<String> PICTURE_REQUESTS = Sets.newHashSet();

    public EntityCanvas(class_1937 world, class_1799 stack, class_2338 pos, class_2350 facing, CanvasType canvasType, int rotation) {
        super(Entities.CANVAS, world, pos);
        String id = Objects.requireNonNullElse(stack.method_57824(Items.CANVAS_ID), "");
        int version = stack.method_57825(Items.CANVAS_VERSION, 0);
        String title = stack.method_57824(Items.CANVAS_TITLE);
        String author = stack.method_57824(Items.CANVAS_AUTHOR);
        this.setCanvasID(id);
        this.setVersion(version);
        if (title != null && author != null) {
            this.canvasSigned = true;
            this.canvasTitle = title;
            this.canvasAuthor = author;
            this.canvasGeneration = stack.method_57825(Items.CANVAS_GENERATION, 0);
        } else {
            this.canvasSigned = false;
        }
        this.setCanvasType(canvasType);
        this.setGlass(stack.method_7909() instanceof ItemCanvas itemCanvas && itemCanvas.isGlass());
        this.setRotation(rotation);
        this.method_6892(facing);

        Picture picture = PICTURES.get(id);
        if (picture == null || picture.version < version) {
            int[] pixels = new int[0];
            List<Integer> pixelList = stack.method_57824(Items.CANVAS_PIXELS);
            if (pixelList != null) {

                pixels = pixelList.stream().mapToInt(i -> i).toArray();
            }
            boolean sidesActive = stack.method_57825(Items.CANVAS_SIDES_ACTIVE, false);
            int[] sidePixels = new int[0];
            List<Integer> sideList = stack.method_57824(Items.CANVAS_SIDE_PIXELS);
            if (sideList != null) {
                sidePixels = sideList.stream().mapToInt(i -> i).toArray();
            }
            PICTURES.put(id, new Picture(version, pixels, sidesActive, sidePixels));
        }
    }

    public EntityCanvas(class_1299<EntityCanvas> entityCanvasEntityType, class_1937 level) {
        super(entityCanvasEntityType, level);
        clientPictureInit(level);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof EntityCanvas other)) {
            return false;
        }
        return Objects.equals(this.method_5667(), other.method_5667());
    }

    @Override
    public int hashCode() {
        return Objects.hash(EntityCanvas.class, this.method_5667());
    }

    private void clientPictureInit(class_1937 level) {
        if (!level.field_9236) {
            return;
        }

        String canvasID = getCanvasID();
        int version = getVersion();
        if (!canvasID.isEmpty() && version > 0) {
            Picture picture = PICTURES.get(getCanvasID());
            if ((picture == null || picture.version < getVersion()) && !isPictureRequested(canvasID)) {
                markPictureRequested(canvasID);
                ClientPlayNetworking.send(new PictureRequestPacket(canvasID));
            }
        }
    }

    public static boolean isPictureRequested(String canvasId) {
        return PICTURE_REQUESTS.contains(canvasId);
    }

    public static void markPictureRequested(String canvasId) {
        PICTURE_REQUESTS.add(canvasId);
    }

    public static void clearPictureRequest(String canvasId) {
        PICTURE_REQUESTS.remove(canvasId);
    }

    @Override
    protected void method_5693(class_2945.@NotNull class_9222 builder) {
        builder.method_56912(CANVAS_ID, "");
        builder.method_56912(CANVAS_VERSION, 0);
        builder.method_56912(CANVAS_TYPE_KEY, (byte) 0);
        builder.method_56912(CANVAS_ROTATION, (byte) 0);
        builder.method_56912(CANVAS_GLASS, false);
    }

    @Override
    public void method_5674(class_2940<?> key) {
        if (CANVAS_TYPE_KEY.equals(key)) {
            this.method_6895();
        } else if (CANVAS_ID.equals(key) || CANVAS_VERSION.equals(key)) {
            clientPictureInit(this.method_37908());
        }
    }

    // Creates the blocksize of the painting based on pixel height and width
    public int getWidth() {
        return CanvasType.getWidth(requireCanvasType());
    }

    public int getHeight() {
        return CanvasType.getHeight(requireCanvasType());
    }

    @Override
    public void method_6889(@Nullable class_1297 brokenEntity) {
        if (this.method_37908().method_8450().method_8355(class_1928.field_19393)) {
            this.method_5783(isGlass() ? class_3417.field_15081 : class_3417.field_14809, 1.0F, 1.0F);
            if (brokenEntity instanceof class_1657 playerEntity && playerEntity.method_31549().field_7477) {
                return;
            }
            CanvasType canvasType = requireCanvasType();
            class_1799 canvasItem = new class_1799(ItemCanvas.canvasItemFor(canvasType, isGlass()));

            canvasItem.method_57379(Items.CANVAS_ID, getCanvasID());
            canvasItem.method_57379(Items.CANVAS_VERSION, getVersion());
            if (canvasSigned) {
                canvasItem.method_57379(Items.CANVAS_AUTHOR, canvasAuthor);
                canvasItem.method_57379(Items.CANVAS_TITLE, canvasTitle);
                canvasItem.method_57379(Items.CANVAS_GENERATION, canvasGeneration);
            }
            ItemCanvas.updateStackSize(canvasItem);
            Picture picture = PICTURES.get(getCanvasID());
            if (picture != null) {
                canvasItem.method_57379(Items.CANVAS_PIXELS, Arrays.stream(picture.pixels).boxed().toList());
                if (picture.sidePixels().length > 0) {
                    canvasItem.method_57379(Items.CANVAS_SIDES_ACTIVE, picture.sidesActive());
                    canvasItem.method_57379(Items.CANVAS_SIDE_PIXELS, Arrays.stream(picture.sidePixels()).boxed().toList());
                }
            }
            this.method_5775(canvasItem);
        }
    }

    @Override
    public void method_5773() {
        this.field_6014 = this.method_23317();
        this.field_6036 = this.method_23318();
        this.field_5969 = this.method_23321();
        boolean shouldCheckSurvival = this.tickCounter1 == 50;
        this.tickCounter1++;
        if (shouldCheckSurvival && !this.method_37908().field_9236) {
            this.tickCounter1 = 0;
            if (this.method_5805() && !this.method_6888()) {
                this.method_5650(class_5529.field_26999);
                this.method_6889(null);
            }
        }
    }

    @Override
    public void method_6894() {
        this.method_5783(isGlass() ? class_3417.field_14843 : class_3417.field_14875, 1.0F, 1.0F);
    }

    @Override
    protected void method_6892(class_2350 facingDirectionIn) {
        this.field_7099 = facingDirectionIn;
        if (facingDirectionIn.method_10166().method_10179()) {
            this.method_36457(0.0F);
            this.method_36456((this.field_7099.method_10161() * 90));
        } else {
            this.method_36457((-90 * facingDirectionIn.method_10171().method_10181()));
            this.method_36456(0.0F);
        }

        this.field_6004 = this.method_36455();
        this.field_5982 = this.method_36454();
        this.method_6895();
    }

    private double offs(int l) {
        return l % 32 == 0 ? 0.5D : 0.0D;
    }

    @Override
    public void method_5808(double x, double y, double z, float yRot, float xRot) {
        this.method_5814(x, y, z);
    }

    @Override
    public void method_5759(double x, double y, double z, float yRot, float xRot, int steps) {
        this.method_5814(x, y, z);
    }

    @Override
    protected class_238 method_59943(class_2338 pos, class_2350 direction) {
        double d1 = pos.method_10263() + 0.5D - direction.method_10148() * 0.46875D;
        double d2 = pos.method_10264() + 0.5D - direction.method_10164() * 0.46875D;
        double d3 = pos.method_10260() + 0.5D - direction.method_10165() * 0.46875D;

        if (direction.method_10166().method_10179()) {
            double d4 = this.offs(this.getWidth());
            double d5 = this.offs(this.getHeight());
            d2 = d2 + d5;
            class_2350 ccwDirection = direction.method_10160();
            d1 = d1 + d4 * ccwDirection.method_10148();
            d3 = d3 + d4 * ccwDirection.method_10165();
        }

        double d6 = this.getWidth();
        double d7 = this.getHeight();
        double d8 = this.getWidth();
        class_2350.class_2351 axis = direction.method_10166();
        switch (axis) {
            case field_11048 -> d6 = 1.0D;
            case field_11052 -> d7 = 1.0D;
            case field_11051 -> d8 = 1.0D;
        }

        d6 = d6 / 32.0D;
        d7 = d7 / 32.0D;
        d8 = d8 / 32.0D;
        return new class_238(d1 - d6, d2 - d7, d3 - d8, d1 + d6, d2 + d7, d3 + d8);
    }

    @Override
    public boolean method_6888() {
        if (field_7099.method_10166().method_10179()) {
            return super.method_6888();
        }
        class_1937 level = this.method_37908();
        if (!level.method_17892(this)) {
            return false;
        } else {
            class_2338 supportPos = this.field_51589.method_10093(this.field_7099.method_10153());
            class_2680 state = level.method_8320(supportPos);
            return (state.method_26206(level, supportPos, this.field_7099) ||
                    (this.field_7099.method_10166().method_10179() && class_2312.method_9999(state)))
                    && level.method_8333(this, this.method_5829(), field_7098).isEmpty();
        }
    }

    @Override
    public class_243 method_31166(float partialTick) {
        return class_243.method_24953(this.field_51589);
    }

    public int getRotation() {
        return this.method_5841().method_12789(CANVAS_ROTATION);
    }

    private void setRotation(int rotation) {
        this.method_5841().method_12778(CANVAS_ROTATION, (byte) (rotation % 4));
    }

    public String getCanvasID() {
        return this.method_5841().method_12789(CANVAS_ID);
    }

    private void setCanvasID(String canvasID) {
        this.method_5841().method_12778(CANVAS_ID, canvasID);
    }

    public int getVersion() {
        return this.method_5841().method_12789(CANVAS_VERSION);
    }

    private void setVersion(int version) {
        this.method_5841().method_12778(CANVAS_VERSION, version);
    }

    public CanvasType getCanvasType() {
        return CanvasType.fromByte(this.method_5841().method_12789(CANVAS_TYPE_KEY));
    }

    public byte getCanvasTypeKey() {
        return this.method_5841().method_12789(CANVAS_TYPE_KEY);
    }

    private void setCanvasType(CanvasType canvasType) {
        this.method_5841().method_12778(CANVAS_TYPE_KEY, canvasType.toByte());
    }

    public boolean isGlass() {
        return this.method_5841().method_12789(CANVAS_GLASS);
    }

    private void setGlass(boolean glass) {
        this.method_5841().method_12778(CANVAS_GLASS, glass);
    }

    @Override
    public class_2596<class_2602> method_18002(class_3231 entity) {
        return new class_2604(this, this.field_7099.method_10146(), this.method_59940());
    }

    @Override
    public void method_31471(class_2604 packet) {
        super.method_31471(packet);
        this.method_6892(class_2350.method_10143(packet.method_11166()));
    }

    @Override
    public void method_5749(class_2487 tagCompound) {
        this.field_51589 = new class_2338(tagCompound.method_10550("TileX"), tagCompound.method_10550("TileY"), tagCompound.method_10550("TileZ"));
        class_2487 canvasNBT = tagCompound;
        if (tagCompound.method_10545("canvas")) {
            canvasNBT = tagCompound.method_10562("canvas");
        }
        this.canvasSigned = canvasNBT.method_10545("author") && canvasNBT.method_10545("title");
        String canvasId = canvasNBT.method_10558("name");
        this.setCanvasID(canvasId);
        int version = canvasNBT.method_10550("v");
        this.setVersion(version);
        if (canvasSigned) {
            this.canvasAuthor = canvasNBT.method_10558("author");
            this.canvasTitle = canvasNBT.method_10558("title");
            this.canvasGeneration = canvasNBT.method_10550("generation");
        }

        Picture picture = PICTURES.get(canvasId);
        if (picture == null || picture.version < version) {
            boolean sidesActive = canvasNBT.method_10577("sidesActive");
            int[] sidePixels = canvasNBT.method_10561("sidePixels");
            PICTURES.put(canvasId, new Picture(version, canvasNBT.method_10561("pixels"), sidesActive, sidePixels));
        }

        this.setCanvasType(CanvasType.fromByte(tagCompound.method_10571("ctype")));
        this.setGlass(tagCompound.method_10577("glass"));
        if (tagCompound.method_10545("Facing") && !tagCompound.method_10545("RealFace")) {
            int facing = tagCompound.method_10571("Facing");
            class_2350 horizontal = class_2350.method_10139(facing);
            this.method_6892(horizontal);
        } else {
            this.method_6892(class_2350.method_10143(tagCompound.method_10571("RealFace")));
        }
        this.setRotation(tagCompound.method_10571("Rotation"));
    }

    @Override
    public void method_5652(class_2487 tagCompound) {
        class_2338 blockpos = this.method_59940();
        tagCompound.method_10569("TileX", blockpos.method_10263());
        tagCompound.method_10569("TileY", blockpos.method_10264());
        tagCompound.method_10569("TileZ", blockpos.method_10260());
        tagCompound.method_10582("name", getCanvasID());
        tagCompound.method_10569("v", getVersion());
        if (canvasSigned && canvasAuthor != null && canvasTitle != null) {
            tagCompound.method_10582("author", canvasAuthor);
            tagCompound.method_10582("title", canvasTitle);
            tagCompound.method_10569("generation", canvasGeneration);
        }
        tagCompound.method_10567("ctype", getCanvasTypeKey());
        tagCompound.method_10556("glass", isGlass());
        tagCompound.method_10567("RealFace", (byte) this.field_7099.method_10146());
        tagCompound.method_10567("Rotation", (byte) this.getRotation());

        Picture picture = PICTURES.get(getCanvasID());
        if (picture != null) {
            tagCompound.method_10539("pixels", picture.pixels);
            if (picture.sidePixels().length > 0) {
                tagCompound.method_10556("sidesActive", picture.sidesActive());
                tagCompound.method_10539("sidePixels", picture.sidePixels());
            }
        }
    }

    @Override
    public class_1269 method_5688(class_1657 player, class_1268 hand) {
        CanvasType canvasType = this.requireCanvasType();
        if (canvasType == CanvasType.SMALL || canvasType == CanvasType.LARGE || canvasType == CanvasType.EXTRA_LARGE || canvasType == CanvasType.SUPER_LARGE) {
            if (!this.method_37908().field_9236) {
                setRotation(getRotation() + 1);
            }
            return class_1269.field_5812;
        } else {
            return class_1269.field_5811;
        }
    }

    public record Picture(int version, int[] pixels, boolean sidesActive, int[] sidePixels) {
        public Picture {
            pixels = pixels.clone();
            sidePixels = sidePixels.clone();
        }

        @Override
        public int[] pixels() {
            return pixels.clone();
        }

        @Override
        public int[] sidePixels() {
            return sidePixels.clone();
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Picture(
                    int otherVersion, int[] otherPixels, boolean otherSidesActive, int[] otherSidePixels
            )))
                return false;
            return version == otherVersion && sidesActive == otherSidesActive
                    && java.util.Arrays.equals(pixels, otherPixels)
                    && java.util.Arrays.equals(sidePixels, otherSidePixels);
        }

        @Override
        public int hashCode() {
            int result = Integer.hashCode(version);
            result = 31 * result + java.util.Arrays.hashCode(pixels);
            result = 31 * result + Boolean.hashCode(sidesActive);
            result = 31 * result + java.util.Arrays.hashCode(sidePixels);
            return result;
        }

        @Override
        public String toString() {
            return "Picture{" +
                    "version=" + version +
                    ", pixels=" + java.util.Arrays.toString(pixels) +
                    ", sidesActive=" + sidesActive +
                    ", sidePixels=" + java.util.Arrays.toString(sidePixels) +
                    '}';
        }
    }

    private CanvasType requireCanvasType() {
        return java.util.Objects.requireNonNull(this.getCanvasType(), "Canvas type");
    }
}
