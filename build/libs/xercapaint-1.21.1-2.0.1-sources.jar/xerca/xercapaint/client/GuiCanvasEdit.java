package xerca.xercapaint.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1041;
import net.minecraft.class_1074;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_4588;
import net.minecraft.class_7919;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import xerca.xercapaint.CanvasSides;
import xerca.xercapaint.CanvasType;
import xerca.xercapaint.PaletteUtil;
import xerca.xercapaint.SoundEvents;
import xerca.xercapaint.entity.EntityEasel;
import xerca.xercapaint.item.ItemCanvas;
import xerca.xercapaint.item.Items;
import xerca.xercapaint.packets.CanvasMiniUpdatePacket;
import xerca.xercapaint.packets.CanvasUpdatePacket;
import xerca.xercapaint.packets.EaselLeftPacket;
import xerca.xercapaint.packets.PaletteUpdatePacket;

import java.util.*;

import static org.lwjgl.glfw.GLFW.*;

@net.fabricmc.api.Environment(net.fabricmc.api.EnvType.CLIENT)
public class GuiCanvasEdit extends BasePalette {
    private static final int BRUSH_LEVEL_COUNT = 4;
    private static final int SMALL_CANVAS_PIXEL_SCALE = 10;
    private static final int MAX_TITLE_LENGTH = 16;
    private static final int MAX_EASEL_DISTANCE_SQR = 64;
    private static final int MINI_UPDATE_INTERVAL_TICKS = 10;
    private static final int POSITION_UNSET = -1000;

    private double canvasX;
    private double canvasY;
    // CANVAS_XS and YS are the X and Y starting point of the GUI based upon the number of Canvas sizes in CanvasType.
    // The GUI will glitch and crash if the canvas type doesn't start fully within the screen.
    private static final double[] CANVAS_XS = {-1000, -1000, -1000, -1000, -1000, 100, 100, -1000, 100, 100};
    private static final double[] CANVAS_YS = {-1000, -1000, -1000, -1000, -1000, 100, 100, -1000, 100, 100};
    private final int canvasWidth;
    private final int canvasHeight;
    private int brushMeterX;
    private int brushMeterY;
    private int brushOpacityMeterX;
    private int brushOpacityMeterY;
    private final int canvasPixelScale;
    private final int canvasPixelWidth;
    private final int canvasPixelHeight;
    private int brushSize;
    private boolean touchedCanvas;
    private boolean undoStarted;
    private boolean gettingSigned;
    private boolean isCarryingCanvas;
    private @Nullable class_4185 buttonSign;
    private @Nullable class_4185 buttonCancel;
    private @Nullable class_4185 buttonFinalize;
    private int updateCount;
    private @Nullable BrushSound brushSound;
    private static final int CANVAS_HOLDER_HEIGHT = 10;
    private int brushOpacitySetting;
    private static final float[] BRUSH_OPACITIES = {1.f, 0.75f, 0.5f, 0.25f};
    private static boolean showHelp;
    private final Set<Integer> draggedPoints = new HashSet<>();

    private static final int SIDES_TOGGLE_SIZE = 8;
    private boolean sidesActive;
    private int @Nullable [] sidePixels;
    private int sidesToggleX;
    private int sidesToggleY;

    private final class_1657 editingPlayer;

    private final CanvasType canvasType;
    private final boolean glass;
    private boolean isSigned;
    private int[] pixels;
    private String canvasTitle = "";
    private final String canvasId;
    private int version;
    private final @Nullable EntityEasel easel;
    private int timeSinceLastUpdate;
    private boolean skippedUpdate;

    private static final class_241[] OUTLINE_POSS_1 = {
            new class_241(0.f, 199.0f),
            new class_241(12.f, 199.0f),
            new class_241(34.f, 199.0f),
            new class_241(76.f, 199.0f),
    };

    private static final class_241[] OUTLINE_POSS_2 = {
            new class_241(128.f, 199.0f),
            new class_241(135.f, 199.0f),
            new class_241(147.f, 199.0f),
            new class_241(169.f, 199.0f),
    };

    private static final int MAX_UNDO_LENGTH = 16;
    private final Deque<Snapshot> undoStack = new ArrayDeque<>(MAX_UNDO_LENGTH);

    /**
     * A snapshot of the editable canvas state for both front and side pixels
     */
    private record Snapshot(int[] pixels, int[] sidePixels) {
    }

    protected GuiCanvasEdit(class_1657 player, class_1799 canvasStack, class_1799 paletteStack, class_2561 title, CanvasType canvasType, boolean glass, @Nullable EntityEasel easel) {
        super(title, paletteStack);
        updateCount = 0;

        this.canvasType = canvasType;
        this.glass = glass;
        if (canvasType == CanvasType.SMALL) {
            this.canvasPixelScale = 10;
        } else if (canvasType == CanvasType.EXTRA_LARGE || canvasType == CanvasType.EXTRA_TALL || canvasType == CanvasType.EXTRA_LONG) {
            this.canvasPixelScale = 4;
        } else if (canvasType == CanvasType.SUPER_LARGE || canvasType == CanvasType.SUPER_TALL || canvasType == CanvasType.SUPER_LONG) {
            this.canvasPixelScale = 3;
        } else {
            this.canvasPixelScale = 5;
        }
        this.canvasPixelWidth = CanvasType.getWidth(canvasType);
        this.canvasPixelHeight = CanvasType.getHeight(canvasType);
        int canvasPixelArea = canvasPixelHeight * canvasPixelWidth;
        this.canvasWidth = this.canvasPixelWidth * this.canvasPixelScale;
        this.canvasHeight = this.canvasPixelHeight * this.canvasPixelScale;
        this.easel = easel;

        this.editingPlayer = player;
        List<Integer> stackPixels = canvasStack.method_57824(Items.CANVAS_PIXELS);
        String stackCanvasId = canvasStack.method_57824(Items.CANVAS_ID);
        if (stackPixels != null && stackCanvasId != null) {
            this.pixels = stackPixels.stream().mapToInt(i -> i).toArray();
            this.canvasId = stackCanvasId;
            this.version = canvasStack.method_57825(Items.CANVAS_VERSION, 1);

            canvasTitle = canvasStack.method_57825(Items.CANVAS_TITLE, "");
            isSigned = !canvasTitle.isEmpty();
        } else {
            this.pixels = new int[canvasPixelArea];
            Arrays.fill(this.pixels, glass ? 0 : BASIC_COLORS[15].rgbVal());

            this.canvasId = ItemCanvas.generateName(player);
        }

        this.sidesActive = canvasStack.method_57825(Items.CANVAS_SIDES_ACTIVE, false);
        List<Integer> stackSidePixels = canvasStack.method_57824(Items.CANVAS_SIDE_PIXELS);
        if (stackSidePixels != null && stackSidePixels.size() == CanvasSides.count(canvasType)) {
            this.sidePixels = stackSidePixels.stream().mapToInt(i -> i).toArray();
        }
    }

    private void ensureSidePixels() {
        if (sidePixels == null || sidePixels.length != CanvasSides.count(canvasType)) {
            sidePixels = CanvasSides.defaultPixels(canvasType, glass);
        }
    }

    private int getSidePixel(int index) {
        if (sidePixels != null && index >= 0 && index < sidePixels.length) {
            return sidePixels[index];
        }
        return CanvasSides.DEFAULT_COLOR;
    }

    private int sideMargin() {
        return sidesActive ? canvasPixelScale : 0;
    }

    @Override
    public void method_25426() {
        if (field_22787 == null) {
            return;
        }
        int typeIndex = canvasType.toByte();
        canvasX = CANVAS_XS[typeIndex];
        canvasY = CANVAS_YS[typeIndex];
        paletteX = PALETTE_XS[typeIndex];
        paletteY = PALETTE_YS[typeIndex];
        if (canvasX == POSITION_UNSET || canvasY == POSITION_UNSET || paletteX == POSITION_UNSET || paletteY == POSITION_UNSET) {
            resetPositions();
        }

        updateCanvasPos(0, 0);
        updatePalettePos(0, 0);

        class_1041 window = field_22787.method_22683();

        // Hide mouse cursor
        glfwSetInputMode(window.method_4490(), GLFW_CURSOR, GLFW_CURSOR_HIDDEN);

        int x = window.method_4486() - 120;
        int y = window.method_4502() - 30;
        this.buttonSign = this.method_37063(class_4185.method_46430(class_2561.method_43471("canvas.signButton"), button -> {
            if (!isSigned) {
                gettingSigned = true;
                resetPositions();
                updateButtons();

                glfwSetInputMode(window.method_4490(), GLFW_CURSOR, GLFW_CURSOR_NORMAL);
            }
        }).method_46434(x, y, 98, 20).method_46431());
        this.buttonFinalize = this.method_37063(class_4185.method_46430(class_2561.method_43471("canvas.finalizeButton"), button -> {
            if (!isSigned) {
                canvasDirty = true;
                isSigned = true;
                if (field_22787 != null) {
                    field_22787.method_1507(null);
                }
            }

        }).method_46434((int) canvasX - 100, 100, 98, 20).method_46431());
        this.buttonCancel = this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.cancel"), button -> {
            if (!isSigned) {
                gettingSigned = false;
                updateButtons();

                glfwSetInputMode(window.method_4490(), GLFW_CURSOR, GLFW_CURSOR_HIDDEN);
            }
        }).method_46434((int) canvasX - 100, 130, 98, 20).method_46431());

        x = (int) (window.method_4486() * 0.95) - 21;
        y = (int) (window.method_4502() * 0.05);
        ToggleHelpButton toggleHelpButton = this.method_37063(new ToggleHelpButton(x, y, 21, 21, 197, 0, 21,
                PALETTE_TEXTURES, 256, 256, button -> showHelp = !showHelp));
        toggleHelpButton.method_47400(class_7919.method_47407(class_2561.method_43471("canvas.help.toggleHelp")));

        updateButtons();
    }

    private void updateButtons() {
        if (!this.isSigned) {
            if (this.buttonSign != null) {
                this.buttonSign.field_22764 = !this.gettingSigned;
            }
            if (this.buttonCancel != null) {
                this.buttonCancel.field_22764 = this.gettingSigned;
                this.buttonCancel.method_46421((int) canvasX - 100);
            }
            if (this.buttonFinalize != null) {
                this.buttonFinalize.field_22764 = this.gettingSigned;
                this.buttonFinalize.field_22763 = !this.canvasTitle.trim().isEmpty();
                this.buttonFinalize.method_46421((int) canvasX - 100);
            }
        }
    }

    private int getPixelAt(int x, int y) {
        return this.pixels[y * canvasPixelWidth + x];
    }

    private static final int[][][] BRUSH_OFFSETS = {
            {{0, 0}},
            {{0, 0}, {-1, 0}, {0, -1}, {-1, -1}},
            {{-1, 1}, {0, 1}, {-2, 0}, {-1, 0}, {0, 0}, {1, 0}, {-2, -1}, {-1, -1}, {0, -1}, {1, -1}, {-1, -2}, {0, -2}},
            {{-1, 2}, {0, 2}, {1, 2}, {-2, 1}, {-1, 1}, {0, 1}, {1, 1}, {2, 1}, {-2, 0}, {-1, 0}, {0, 0}, {1, 0}, {2, 0}, {-2, -1}, {-1, -1}, {0, -1}, {1, -1}, {2, -1}, {-1, -2}, {0, -2}, {1, -2}}
    };
    /**
     * Whether each brush anchors on the nearest grid corner (true) or the cell under the cursor (false).
     */
    private static final boolean[] BRUSH_CORNER_ANCHOR = {false, true, true, false};
    /**
     * The smallest offset and the span (in cells) of each brush's bounding box, used to draw the outline.
     */
    private static final int[] BRUSH_MIN_OFFSET = {0, -1, -2, -2};
    private static final int[] BRUSH_SPAN = {1, 2, 4, 5};

    private int brushAnchor(int mousePos, int origin, boolean corner) {
        int rel = mousePos - origin + (corner ? canvasPixelScale / 2 : 0);
        return Math.floorDiv(rel, canvasPixelScale);
    }

    /**
     * Maps a grid cell that lies outside the canvas to its side-pixel index, or -1 if it is not a side cell.
     */
    private int sideIndexFor(int col, int row) {
        int w = canvasPixelWidth;
        int h = canvasPixelHeight;
        if (row == -1 && col >= 0 && col < w) {
            return CanvasSides.topOffset() + col;
        }
        if (row == h && col >= 0 && col < w) {
            return CanvasSides.bottomOffset(canvasType) + col;
        }
        if (col == -1 && row >= 0 && row < h) {
            return CanvasSides.leftOffset(canvasType) + row;
        }
        if (col == w && row >= 0 && row < h) {
            return CanvasSides.rightOffset(canvasType) + row;
        }
        return -1;
    }

    private void paintCell(int col, int row, PaletteUtil.Color color, float opacity, boolean erase) {
        boolean onCanvas = col >= 0 && col < canvasPixelWidth && row >= 0 && row < canvasPixelHeight;
        int sideIndex = -1;
        if (!onCanvas) {
            if (!sidesActive) {
                return;
            }
            sideIndex = sideIndexFor(col, row);
            if (sideIndex < 0) {
                return;
            }
        }
        int key = onCanvas ? row * canvasPixelWidth + col : canvasPixelWidth * canvasPixelHeight + sideIndex;
        if (!draggedPoints.add(key)) {
            return;
        }
        if (onCanvas) {
            int i = row * canvasPixelWidth + col;
            pixels[i] = blendPixel(pixels[i], color, opacity, erase);
        } else {
            ensureSidePixels();
            if (sidePixels == null) {
                return;
            }
            sidePixels[sideIndex] = blendPixel(sidePixels[sideIndex], color, opacity, erase);
        }
    }

    /**
     * Combines a brush stroke with an existing pixel; glass uses binary transparency (erase clears, paint is opaque).
     */
    private int blendPixel(int old, PaletteUtil.Color color, float opacity, boolean erase) {
        if (glass) {
            if (erase) {
                return 0;
            }
            if (((old >> 24) & 0xFF) == 0) {
                return color.rgbVal();
            }
        }
        return PaletteUtil.Color.mix(color, new PaletteUtil.Color(old), opacity).rgbVal();
    }

    private void paintAt(int mouseX, int mouseY, int mouseButton) {
        touchedCanvas = true;
        boolean erase = mouseButton == GLFW_MOUSE_BUTTON_RIGHT;
        PaletteUtil.Color color = erase ? PaletteUtil.Color.WHITE : currentColor;
        float opacity = erase ? 1.0f : BRUSH_OPACITIES[brushOpacitySetting];
        boolean corner = BRUSH_CORNER_ANCHOR[brushSize];
        int anchorCol = brushAnchor(mouseX, (int) canvasX, corner);
        int anchorRow = brushAnchor(mouseY, (int) canvasY, corner);
        for (int[] offset : BRUSH_OFFSETS[brushSize]) {
            paintCell(anchorCol + offset[0], anchorRow + offset[1], color, opacity, erase);
        }
        canvasDirty = true;
    }

    private boolean overSide(int mouseX, int mouseY) {
        if (!sidesActive) {
            return false;
        }
        int col = Math.floorDiv(mouseX - (int) canvasX, canvasPixelScale);
        int row = Math.floorDiv(mouseY - (int) canvasY, canvasPixelScale);
        return sideIndexFor(col, row) >= 0;
    }

    private boolean inPaintable(int mouseX, int mouseY) {
        return inCanvas(mouseX, mouseY) || overSide(mouseX, mouseY);
    }

    /**
     * Returns the color of the canvas/side cell under the cursor, or null if it is not a paintable cell.
     */
    private @Nullable Integer cellColorAt(int mouseX, int mouseY) {
        int col = Math.floorDiv(mouseX - (int) canvasX, canvasPixelScale);
        int row = Math.floorDiv(mouseY - (int) canvasY, canvasPixelScale);
        if (col >= 0 && col < canvasPixelWidth && row >= 0 && row < canvasPixelHeight) {
            return pixels[row * canvasPixelWidth + col];
        }
        if (sidesActive) {
            int sideIndex = sideIndexFor(col, row);
            if (sideIndex >= 0) {
                return getSidePixel(sideIndex);
            }
        }
        return null;
    }

    private void resetPositions() {
        final int padding = 40;
        final int paletteCanvasX = (this.field_22789 - (PALETTE_WIDTH + canvasWidth + padding)) / 2;
        canvasX = (double) paletteCanvasX + PALETTE_WIDTH + padding;
        if (canvasType == CanvasType.LONG) {
            canvasY = 80;
        } else {
            canvasY = 40;
        }

        paletteX = paletteCanvasX;
        paletteY = 40;
    }

    @Override
    public void method_25393() {
        ++this.updateCount;
        ++this.timeSinceLastUpdate;

        if (easel != null) {
            if (easel.getItem().method_7960() || easel.method_31481() || easel.method_5858(editingPlayer) > MAX_EASEL_DISTANCE_SQR) {
                this.method_25419();
            }
            if (skippedUpdate && timeSinceLastUpdate > 20 && canvasDirty) {
                updateCanvas(false);
                skippedUpdate = false;
            }
        }

        super.method_25393();
    }

    @Override
    protected void method_57734(float partialTick) {
        // Skip vanilla's world-blur behind the painting GUI so the scene stays crisp
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float f) {
        if (!gettingSigned) {
            super.method_25394(guiGraphics, mouseX, mouseY, f);
        } else {
            super.superRender(guiGraphics, mouseX, mouseY, f);
        }

        // Write cells straight into the shared GUI buffer (guiGraphics.fill flushes per quad and tanks the FPS)
        Matrix4f matrix = guiGraphics.method_51448().method_23760().method_23761();
        class_4588 canvasBuffer = guiGraphics.method_51450().getBuffer(class_1921.method_51784());

        // Draw the canvas holder
        int holderMargin = sideMargin();
        batchFill(canvasBuffer, matrix, (int) (canvasX + canvasWidth * 0.25), (int) canvasY - CANVAS_HOLDER_HEIGHT - holderMargin, (int) (canvasX + canvasWidth * 0.75), (int) canvasY - holderMargin, 0xffe1e1e1);

        // For glass canvases, draw a transparency checkerboard so empty cells are visible
        if (glass) {
            for (int i = 0; i < canvasPixelHeight; i++) {
                for (int j = 0; j < canvasPixelWidth; j++) {
                    fillChecker(canvasBuffer, matrix, (int) canvasX + j * canvasPixelScale, (int) canvasY + i * canvasPixelScale, i + j);
                }
            }
        }

        // Draw the canvas
        for (int i = 0; i < canvasPixelHeight; i++) {
            for (int j = 0; j < canvasPixelWidth; j++) {
                int y = (int) canvasY + i * canvasPixelScale;
                int x = (int) canvasX + j * canvasPixelScale;
                batchFill(canvasBuffer, matrix, x, y, x + canvasPixelScale, y + canvasPixelScale, getPixelAt(j, i));
            }
        }

        if (!gettingSigned) {
            // Draw the paintable sides and the toggle button
            if (sidesActive) {
                drawSideLines(canvasBuffer, matrix);
            }
            drawSidesToggle(guiGraphics);

            // Draw brush meter
            for (int i = 0; i < 4; i++) {
                int y = brushMeterY + i * BRUSH_SPRITE_SIZE;
                guiGraphics.method_25294(brushMeterX, y, brushMeterX + 3, y + 3, currentColor.rgbVal());
            }
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            guiGraphics.method_25302(PALETTE_TEXTURES, brushMeterX, brushMeterY + (3 - brushSize) * BRUSH_SPRITE_SIZE, 15, 246, 10, 10);
            guiGraphics.method_25302(PALETTE_TEXTURES, brushMeterX, brushMeterY, BRUSH_SPRITE_X, BRUSH_SPRITE_Y - BRUSH_SPRITE_SIZE * 3, BRUSH_SPRITE_SIZE, BRUSH_SPRITE_SIZE * 4);

            // Draw opacity meter
            guiGraphics.method_25302(PALETTE_TEXTURES, brushOpacityMeterX, brushOpacityMeterY, BRUSH_OPACITY_SPRITE_X, BRUSH_OPACITY_SPRITE_Y, BRUSH_OPACITY_SPRITE_SIZE, BRUSH_OPACITY_SPRITE_SIZE * 4 + 3);
            guiGraphics.method_25302(PALETTE_TEXTURES, brushOpacityMeterX - 1, brushOpacityMeterY - 1 + brushOpacitySetting * (BRUSH_OPACITY_SPRITE_SIZE + 1), 212, 240, 16, 16);

            // Draw brush and outline
            renderCursor(guiGraphics, mouseX, mouseY);

            if (showHelp) {
                if (inBrushMeter(mouseX, mouseY)) {
                    int selectedSize = 3 - (mouseY - brushMeterY) / BRUSH_SPRITE_SIZE;
                    if (selectedSize <= 6 && selectedSize >= 0) {
                        guiGraphics.method_51438(field_22793, class_2561.method_43469("canvas.help.brushSize", selectedSize + 1), mouseX, mouseY);
                    }
                } else if (inBrushOpacityMeter(mouseX, mouseY)) {
                    int relativeY = mouseY - brushOpacityMeterY;
                    int selectedOpacity = relativeY / (BRUSH_OPACITY_SPRITE_SIZE + 1);
                    if (selectedOpacity >= 0 && selectedOpacity <= 3) {
                        int percentage = 100 - 25 * selectedOpacity;
                        guiGraphics.method_51438(field_22793, class_2561.method_43469("canvas.help.brushOpacity", percentage), mouseX, mouseY);
                    }
                } else if (inColorPicker(mouseX - (int) paletteX, mouseY - (int) paletteY)) {
                    guiGraphics.method_51434(field_22793, Arrays.asList(class_2561.method_43471("canvas.help.colorPicker"),
                            class_2561.method_43471("canvas.help.colorPicker.desc").method_27692(class_124.field_1080)), mouseX, mouseY);
                } else if (inWater(mouseX - (int) paletteX, mouseY - (int) paletteY)) {
                    guiGraphics.method_51434(field_22793, Arrays.asList(class_2561.method_43471("canvas.help.colorRemover"),
                            class_2561.method_43471("canvas.help.colorRemover.desc").method_27692(class_124.field_1080)), mouseX, mouseY);
                } else if (inCanvasHolder(mouseX, mouseY)) {
                    guiGraphics.method_51434(field_22793, Arrays.asList(class_2561.method_43471("canvas.help.canvasHolder"),
                            class_2561.method_43471("canvas.help.canvasHolder.desc").method_27692(class_124.field_1080)), mouseX, mouseY);
                } else if (inSidesToggle(mouseX, mouseY)) {
                    guiGraphics.method_51438(field_22793, class_2561.method_43471("canvas.help.toggleSides"), mouseX, mouseY);
                }
            }
        } else {
            drawSigning(guiGraphics);
        }
    }

    private void renderCursor(class_332 guiGraphics, int mouseX, int mouseY) {
        if (isCarryingColor && carriedColor != null) {
            carriedColor.setGLColor();
            guiGraphics.method_25302(PALETTE_TEXTURES, mouseX - BRUSH_SPRITE_SIZE / 2, mouseY - BRUSH_SPRITE_SIZE / 2, BRUSH_SPRITE_X + BRUSH_SPRITE_SIZE, BRUSH_SPRITE_Y, DROP_SPRITE_WIDTH, BRUSH_SPRITE_SIZE);

        } else if (isCarryingWater) {
            WATER_COLOR.setGLColor();
            guiGraphics.method_25302(PALETTE_TEXTURES, mouseX - BRUSH_SPRITE_SIZE / 2, mouseY - BRUSH_SPRITE_SIZE / 2, BRUSH_SPRITE_X + BRUSH_SPRITE_SIZE, BRUSH_SPRITE_Y, DROP_SPRITE_WIDTH, BRUSH_SPRITE_SIZE);
        } else if (isPickingColor) {
            drawOutline(guiGraphics, mouseX, mouseY, 0);
            PaletteUtil.Color.WHITE.setGLColor();
            guiGraphics.method_25302(PALETTE_TEXTURES, mouseX, mouseY - COLOR_PICKER_SIZE, COLOR_PICKER_SPRITE_X, COLOR_PICKER_SPRITE_Y, COLOR_PICKER_SIZE, COLOR_PICKER_SIZE);
        } else {
            drawOutline(guiGraphics, mouseX, mouseY, brushSize);

            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            guiGraphics.method_25294(mouseX, mouseY, mouseX + 3, mouseY + 3, currentColor.rgbVal());

            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            int trueBrushY = BRUSH_SPRITE_Y - BRUSH_SPRITE_SIZE * brushSize;
            guiGraphics.method_25302(PALETTE_TEXTURES, mouseX, mouseY, BRUSH_SPRITE_X, trueBrushY, BRUSH_SPRITE_SIZE, BRUSH_SPRITE_SIZE);
        }
    }

    private void drawOutline(class_332 guiGraphics, int mouseX, int mouseY, int brushSize) {
        // The outline is the brush stamp's bounding box, so it follows the cursor onto the sides too.
        if (!inPaintable(mouseX, mouseY)) {
            return;
        }
        boolean corner = BRUSH_CORNER_ANCHOR[brushSize];
        int anchorCol = brushAnchor(mouseX, (int) canvasX, corner);
        int anchorRow = brushAnchor(mouseY, (int) canvasY, corner);
        int minOffset = BRUSH_MIN_OFFSET[brushSize];
        int outlineSize = BRUSH_SPAN[brushSize] * canvasPixelScale + 2;
        int x = (anchorCol + minOffset) * canvasPixelScale + (int) canvasX - 1;
        int y = (anchorRow + minOffset) * canvasPixelScale + (int) canvasY - 1;

        class_241 textureVec = (canvasPixelScale == SMALL_CANVAS_PIXEL_SCALE) ? OUTLINE_POSS_1[brushSize] : OUTLINE_POSS_2[brushSize];
        RenderSystem.setShaderColor(0.3F, 0.3F, 0.3F, 1.0F);
        guiGraphics.method_25302(PALETTE_TEXTURES, x, y, (int) textureVec.field_1343, (int) textureVec.field_1342, outlineSize, outlineSize);
    }

    private void drawSigning(class_332 guiGraphics) {
        int i = (int) canvasX;
        int j = (int) canvasY;

        guiGraphics.method_25294(i + 10, j + 10, i + 150, j + 150, 0xFFEEEEEE);
        String s = this.canvasTitle;

        if (!this.isSigned) {
            if (this.updateCount / 6 % 2 == 0) {
                s = s + class_124.field_1074 + "_";
            } else {
                s = s + class_124.field_1080 + "_";
            }
        }
        String s1 = class_1074.method_4662("canvas.editTitle");
        int k = this.field_22793.method_1727(s1);
        guiGraphics.method_51433(this.field_22793, s1, (int) (i + 26 + (116 - k) / 2.0f), (j + 16 + 16), 0, false);
        int l = this.field_22793.method_1727(s);
        guiGraphics.method_51433(this.field_22793, s, (int) (i + 26 + (116 - l) / 2.0f), j + 48, 0, false);
        String s2 = class_1074.method_4662("canvas.byAuthor", this.editingPlayer.method_5477().getString());
        int i1 = this.field_22793.method_1727(s2);
        guiGraphics.method_51433(this.field_22793, class_124.field_1063 + s2, (int) (i + 26 + (116 - i1) / 2.0f), j + 48 + 10, 0, false);
        guiGraphics.method_51440(this.field_22793, class_2561.method_43471("canvas.finalizeWarning"), i + 26, j + 80, 116, 0);
    }

    private void playBrushSound() {
        brushSound = new BrushSound();
        playSound(brushSound);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (this.gettingSigned) {
            switch (Integer.valueOf(keyCode)) {
                case Integer k when k == GLFW_KEY_BACKSPACE && !this.canvasTitle.isEmpty() -> {
                    this.canvasTitle = this.canvasTitle.substring(0, this.canvasTitle.length() - 1);
                    this.updateButtons();
                }
                case Integer k when k == GLFW_KEY_ENTER && !this.canvasTitle.isEmpty() -> {
                    canvasDirty = true;
                    this.isSigned = true;
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(null);
                    }
                }
                default -> {
                    // Do nothing
                }
            }
            return true;
        } else {
            if (keyCode == GLFW_KEY_Z && (modifiers & GLFW_MOD_CONTROL) == GLFW_MOD_CONTROL) {
                if (!undoStack.isEmpty()) {
                    Snapshot snapshot = undoStack.pop();
                    pixels = snapshot.pixels();
                    sidePixels = snapshot.sidePixels();
                    canvasDirty = true;
                    if (easel != null) {
                        updateCanvas(false);
                    }
                }
                return true;
            } else {
                if (keyCode == GLFW_KEY_O) {
                    brushOpacitySetting += 1;
                    if (brushOpacitySetting >= BRUSH_LEVEL_COUNT) {
                        brushOpacitySetting = 0;
                    }
                }
                return super.method_25404(keyCode, scanCode, modifiers);
            }
        }
    }

    private static boolean isAllowedChatCharacter(char var0) {
        return var0 != 167 && var0 >= ' ' && var0 != 127;
    }

    @Override
    public boolean method_25400(char typedChar, int something) {
        super.method_25400(typedChar, something);

        if (!this.isSigned) {
            if (this.gettingSigned && this.canvasTitle.length() < MAX_TITLE_LENGTH && isAllowedChatCharacter(typedChar)) {
                this.canvasTitle = this.canvasTitle + typedChar;
                this.updateButtons();
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25401(double posX, double posY, double scrollX, double scrollY) {
        int mouseX = (int) Math.floor(posX);
        int mouseY = (int) Math.floor(posY);
        if (!gettingSigned && scrollY != 0.d) {
            if (inBrushOpacityMeter(mouseX, mouseY)) {
                final int maxBrushOpacity = BRUSH_LEVEL_COUNT - 1;
                brushOpacitySetting += scrollY < 0 ? 1 : -1;
                if (brushOpacitySetting > maxBrushOpacity) brushOpacitySetting = 0;
                else if (brushOpacitySetting < 0) brushOpacitySetting = maxBrushOpacity;
                return true;
            } else {
                final int maxBrushSize = BRUSH_LEVEL_COUNT - 1;
                brushSize += scrollY > 0 ? 1 : -1;
                if (brushSize > maxBrushSize) brushSize = 0;
                else if (brushSize < 0) brushSize = maxBrushSize;
                return true;
            }
        }
        return super.method_25401(posX, posY, scrollX, scrollY);
    }

    // Mouse button 0: left, 1: right
    @Override
    public boolean method_25402(double posX, double posY, int mouseButton) {
        if (gettingSigned) {
            return super.superMouseClicked(posX, posY, mouseButton);
        }

        int mouseX = (int) Math.floor(posX);
        int mouseY = (int) Math.floor(posY);

        undoStarted = true;
        touchedCanvas = false;
        if (undoStack.size() >= MAX_UNDO_LENGTH) {
            undoStack.removeLast();
        }
        int[] sideSnapshot = sidePixels != null ? sidePixels.clone() : CanvasSides.defaultPixels(canvasType, glass);
        undoStack.push(new Snapshot(pixels.clone(), sideSnapshot));

        if (inSidesToggle(mouseX, mouseY)) {
            toggleSides();
            return super.superMouseClicked(mouseX, mouseY, mouseButton);
        }

        if (inPaintable(mouseX, mouseY)) {
            if (isPickingColor) {
                Integer color = cellColorAt(mouseX, mouseY);
                if (color != null) {
                    carriedColor = new PaletteUtil.Color(color);
                    setCarryingColor();
                    playSound(SoundEvents.COLOR_PICKER_SUCK);
                }
            } else {
                paintAt(mouseX, mouseY, mouseButton);
                playBrushSound();
            }
            return super.superMouseClicked(mouseX, mouseY, mouseButton);
        }

        if (inBrushMeter(mouseX, mouseY)) {
            int selectedSize = 3 - (mouseY - brushMeterY) / BRUSH_SPRITE_SIZE;
            if (selectedSize <= 6 && selectedSize >= 0) {
                brushSize = selectedSize;
            }
            return super.superMouseClicked(mouseX, mouseY, mouseButton);
        }
        if (inBrushOpacityMeter(mouseX, mouseY)) {
            int relativeY = mouseY - brushOpacityMeterY;
            int selectedOpacity = relativeY / (BRUSH_OPACITY_SPRITE_SIZE + 1);
            if (selectedOpacity >= 0 && selectedOpacity <= 3) {
                brushOpacitySetting = selectedOpacity;
            }
            return super.superMouseClicked(mouseX, mouseY, mouseButton);
        }
        if (inCanvasHolder(mouseX, mouseY)) {
            isCarryingCanvas = true;
        }
        return super.method_25402(mouseX, mouseY, mouseButton);
    }

    @Override
    public boolean method_25406(double posX, double posY, int mouseButton) {
        isCarryingCanvas = false;
        if (gettingSigned) {
            return super.superMouseReleased(posX, posY, mouseButton);
        }
        draggedPoints.clear();

        if (undoStarted && !touchedCanvas) {
            undoStarted = false;
            undoStack.removeFirst();
        }

        if (brushSound != null) {
            brushSound.stopSound();
        }

        if (easel != null) {
            updateCanvas(false);
        }

        return super.method_25406(posX, posY, mouseButton);
    }

    @Override
    public boolean method_25403(double posX, double posY, int mouseButton, double deltaX, double deltaY) {
        if (gettingSigned) {
            return super.superMouseDragged(posX, posY, mouseButton, deltaX, deltaY);
        }
        if (!isCarryingColor && !isCarryingWater && !isPickingColor && !isCarryingPalette && !isCarryingCanvas) {
            int mouseX = (int) Math.floor(posX);
            int mouseY = (int) Math.floor(posY);
            if (inPaintable(mouseX, mouseY)) {
                paintAt(mouseX, mouseY, mouseButton);
            }

            if (brushSound != null) {
                brushSound.refreshFade();
            }
        } else if (isCarryingCanvas) {
            updateCanvasPos(deltaX, deltaY);
            return super.superMouseDragged(posX, posY, mouseButton, deltaX, deltaY);
        } else if (isCarryingPalette) {
            boolean ret = super.method_25403(posX, posY, mouseButton, deltaX, deltaY);
            updatePalettePos(deltaX, deltaY);
            return ret;
        }
        return super.method_25403(posX, posY, mouseButton, deltaX, deltaY);
    }

    private void updateCanvasPos(double deltaX, double deltaY) {
        canvasX += deltaX;
        canvasY += deltaY;

        int margin = sideMargin();
        brushMeterX = (int) canvasX + canvasWidth + 2 + margin;
        brushMeterY = (int) canvasY + canvasHeight / 2 + 30;

        brushOpacityMeterX = (int) canvasX + canvasWidth + 2 + margin;
        brushOpacityMeterY = (int) canvasY;

        sidesToggleX = (int) (canvasX + canvasWidth * 0.25) - SIDES_TOGGLE_SIZE - 3;
        sidesToggleY = (int) canvasY - SIDES_TOGGLE_SIZE - 1 - margin;

        int typeIndex = canvasType.toByte();
        CANVAS_XS[typeIndex] = canvasX;
        CANVAS_YS[typeIndex] = canvasY;
    }

    private void updatePalettePos(double deltaX, double deltaY) {
        paletteX += deltaX;
        paletteY += deltaY;

        int typeIndex = canvasType.toByte();
        PALETTE_XS[typeIndex] = paletteX;
        PALETTE_YS[typeIndex] = paletteY;
    }

    private boolean inCanvas(int x, int y) {
        return x < canvasX + canvasWidth && x >= canvasX && y < canvasY + canvasHeight && y >= canvasY;
    }

    private boolean inCanvasHolder(int x, int y) {
        int margin = sideMargin();
        return x < canvasX + canvasWidth * 0.75 && x >= canvasX + canvasWidth * 0.25 && y < canvasY - margin && y >= canvasY - CANVAS_HOLDER_HEIGHT - margin;
    }

    private boolean inSidesToggle(int x, int y) {
        return x >= sidesToggleX && x < sidesToggleX + SIDES_TOGGLE_SIZE && y >= sidesToggleY && y < sidesToggleY + SIDES_TOGGLE_SIZE;
    }

    private static final int CHECKER_LIGHT = 0xFFBFBFBF;
    private static final int CHECKER_DARK = 0xFF7F7F7F;

    /**
     * Writes one coloured quad into the shared GUI buffer, like {@link class_332#method_25294} but without flushing.
     */
    private static void batchFill(class_4588 buffer, Matrix4f matrix, int x1, int y1, int x2, int y2, int color) {
        buffer.method_22918(matrix, x1, y1, 0.0f).method_39415(color);
        buffer.method_22918(matrix, x1, y2, 0.0f).method_39415(color);
        buffer.method_22918(matrix, x2, y2, 0.0f).method_39415(color);
        buffer.method_22918(matrix, x2, y1, 0.0f).method_39415(color);
    }

    private void fillChecker(class_4588 buffer, Matrix4f matrix, int x, int y, int parity) {
        batchFill(buffer, matrix, x, y, x + canvasPixelScale, y + canvasPixelScale, (parity & 1) == 0 ? CHECKER_LIGHT : CHECKER_DARK);
    }

    private void drawSideLines(class_4588 buffer, Matrix4f matrix) {
        int scale = canvasPixelScale;
        int cx = (int) canvasX;
        int cy = (int) canvasY;
        for (int k = 0; k < canvasPixelWidth; k++) {
            int x = cx + k * scale;
            if (glass) {
                fillChecker(buffer, matrix, x, cy - scale, k - 1);
                fillChecker(buffer, matrix, x, cy + canvasHeight, k + canvasPixelHeight);
            }
            batchFill(buffer, matrix, x, cy - scale, x + scale, cy, getSidePixel(CanvasSides.topOffset() + k));
            batchFill(buffer, matrix, x, cy + canvasHeight, x + scale, cy + canvasHeight + scale, getSidePixel(CanvasSides.bottomOffset(canvasType) + k));
        }
        for (int i = 0; i < canvasPixelHeight; i++) {
            int y = cy + i * scale;
            if (glass) {
                fillChecker(buffer, matrix, cx - scale, y, i - 1);
                fillChecker(buffer, matrix, cx + canvasWidth, y, i + canvasPixelWidth);
            }
            batchFill(buffer, matrix, cx - scale, y, cx, y + scale, getSidePixel(CanvasSides.leftOffset(canvasType) + i));
            batchFill(buffer, matrix, cx + canvasWidth, y, cx + canvasWidth + scale, y + scale, getSidePixel(CanvasSides.rightOffset(canvasType) + i));
        }
    }

    private void drawSidesToggle(class_332 guiGraphics) {
        int x = sidesToggleX;
        int y = sidesToggleY;
        int s = SIDES_TOGGLE_SIZE;
        guiGraphics.method_25294(x - 1, y - 1, x + s + 1, y + s + 1, 0xFF000000);
        guiGraphics.method_25294(x, y, x + s, y + s, sidesActive ? 0xFF6699FF : 0xFFB0B0B0);
        int edge = sidesActive ? 0xFFFFFFFF : 0xFF808080;
        guiGraphics.method_25294(x + 1, y + 1, x + s - 1, y + 2, edge);
        guiGraphics.method_25294(x + 1, y + s - 2, x + s - 1, y + s - 1, edge);
        guiGraphics.method_25294(x + 1, y + 2, x + 2, y + s - 2, edge);
        guiGraphics.method_25294(x + s - 2, y + 2, x + s - 1, y + s - 2, edge);
    }

    private void toggleSides() {
        sidesActive = !sidesActive;
        if (sidesActive) {
            ensureSidePixels();
        }
        canvasDirty = true;
        updateCanvasPos(0, 0);
        playSound(SoundEvents.MIX, 0.5f);
        if (easel != null) {
            updateCanvas(false);
        }
    }

    private boolean inBrushMeter(int x, int y) {
        return x < brushMeterX + BRUSH_SPRITE_SIZE && x >= brushMeterX && y < brushMeterY + BRUSH_SPRITE_SIZE * 4 && y >= brushMeterY;
    }

    private boolean inBrushOpacityMeter(int x, int y) {
        return x < brushOpacityMeterX + BRUSH_OPACITY_SPRITE_SIZE && x >= brushOpacityMeterX && y < brushOpacityMeterY + BRUSH_OPACITY_SPRITE_SIZE * 4 + 3 && y >= brushOpacityMeterY;
    }

    @Override
    public void method_25432() {
        updateCanvas(true);
    }

    private void updateCanvas(boolean closing) {
        int[] sideData = sidePixels == null ? new int[0] : sidePixels;
        if (closing) {
            if (canvasDirty) {
                version++;
                int easelId = easel == null ? -1 : easel.method_5628();
                ClientPlayNetworking.send(new CanvasUpdatePacket(pixels, isSigned, canvasTitle, canvasId, version, easelId, customColors, canvasType, sidesActive, sideData));
            } else {
                if (easel != null) {
                    ClientPlayNetworking.send(new EaselLeftPacket(easel.method_5628()));
                }
                if (paletteDirty) {
                    PaletteUpdatePacket pack = new PaletteUpdatePacket(customColors);
                    ClientPlayNetworking.send(pack);
                }
            }
        } else {
            if (canvasDirty) {
                if (timeSinceLastUpdate < MINI_UPDATE_INTERVAL_TICKS) {
                    skippedUpdate = true;
                } else {
                    version++;
                    if (easel != null) {
                        ClientPlayNetworking.send(new CanvasMiniUpdatePacket(pixels, canvasId, version, easel.method_5628(), canvasType, sidesActive, sideData));
                    }
                    canvasDirty = false;
                    timeSinceLastUpdate = 0;
                }
            }
        }
    }

    public static class ToggleHelpButton extends class_4185 {
        protected final class_2960 resourceLocation;
        protected final int xTexStart;
        protected final int yTexStart;
        protected final int yDiffText;
        protected final int texWidth;
        protected final int texHeight;

        public ToggleHelpButton(int x, int y, int width, int height, int xTexStart, int yTexStart, int yDiffText, class_2960 texture, int texWidth, int texHeight, class_4241 onClick) {
            super(x, y, width, height, class_2561.method_43473(), onClick, field_40754);
            this.texWidth = texWidth;
            this.texHeight = texHeight;
            this.xTexStart = xTexStart;
            this.yTexStart = yTexStart;
            this.yDiffText = yDiffText;
            this.resourceLocation = texture;
        }

        protected void postRender() {
            GlStateManager._enableDepthTest();
        }

        @Override
        public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
            RenderSystem.setShaderTexture(0, this.resourceLocation);
            GlStateManager._disableDepthTest();
            int yTexStartNew = this.yTexStart;
            if (this.field_22762) {
                yTexStartNew += this.yDiffText;
            }
            int xTexStartNew = this.xTexStart + (showHelp ? 0 : this.field_22758);
            guiGraphics.method_25290(resourceLocation, this.method_46426(), this.method_46427(), xTexStartNew, yTexStartNew, this.field_22758, this.field_22759, this.texWidth, this.texHeight);
            postRender();
        }
    }
}
