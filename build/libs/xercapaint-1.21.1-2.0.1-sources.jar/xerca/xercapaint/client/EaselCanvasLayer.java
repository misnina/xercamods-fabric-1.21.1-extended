package xerca.xercapaint.client;

import net.minecraft.class_1799;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import xerca.xercapaint.entity.EntityEasel;
import xerca.xercapaint.item.ItemCanvas;

public class EaselCanvasLayer extends class_3887<EntityEasel, EaselModel> {
    public EaselCanvasLayer(class_3883<EntityEasel, EaselModel> layerParent) {
        super(layerParent);
    }

    @Override
    public void render(class_4587 poseStack, class_4597 bufferSource, int i, EntityEasel entity, float v, float v1, float v2, float v3, float v4, float v5) {
        class_1799 itemstack = entity.getItem();
        if (itemstack.method_7909() instanceof ItemCanvas itemCanvas) {
            poseStack.method_22903();

            switch (itemCanvas.getCanvasType()) {
                case SMALL -> {
                    poseStack.method_22905(1.5F, 1.5f, 1.5f);
                    poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40714.rotationDegrees(-15.0F));
                    poseStack.method_22904(-0.5, -1.17, -0.5);
                }
                case LARGE -> {
                    poseStack.method_22905(2F, 2f, 2f);
                    poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40714.rotationDegrees(-15.0F));
                    poseStack.method_22904(-0.45, -1.015, -0.5);
                }
                case LONG -> {
                    poseStack.method_22905(2F, 2f, 2f);
                    poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40714.rotationDegrees(-15.0F));
                    poseStack.method_22904(-0.45, -0.915, -0.5);
                }
                case TALL -> {
                    poseStack.method_22905(2F, 2f, 2f);
                    poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40714.rotationDegrees(-15.0F));
                    poseStack.method_22904(-0.595, -1.015, -0.5);
                }
                case EXTRA_LARGE -> {
                    poseStack.method_22905(1.75F, 1.75f, 1.75f);
                    poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40714.rotationDegrees(-15.0F));
                    poseStack.method_22904(-0.28, -1.0875, -0.5);
                }
                case EXTRA_LONG -> {
                    poseStack.method_22905(1.75F, 1.75f, 1.75f);
                    poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40714.rotationDegrees(-15.0F));
                    poseStack.method_22904(-0.28, -1.0875, -0.5);
                }
                case EXTRA_TALL -> {
                    poseStack.method_22905(1.75F, 1.75f, 1.75f);
                    poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40714.rotationDegrees(-15.0F));
                    poseStack.method_22904(-0.45, -1.0875, -0.5);
                }
                case SUPER_LARGE -> {
                    poseStack.method_22905(1.75F, 1.75f, 1.75f);
                    poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40714.rotationDegrees(-15.0F));
                    poseStack.method_22904(-0.15, -1.0875, -0.5);
                }
                case SUPER_LONG -> {
                    poseStack.method_22905(1.75F, 1.75f, 1.75f);
                    poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40714.rotationDegrees(-15.0F));
                    poseStack.method_22904(-0.15, -1.0875, -0.5);
                }
                case SUPER_TALL -> {
                    poseStack.method_22905(1.75F, 1.75f, 1.75f);
                    poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
                    poseStack.method_22907(class_7833.field_40714.rotationDegrees(-15.0F));
                    poseStack.method_22904(-0.3, -1.0875, -0.5);
                }
            }

            ModClient.requireCanvasItemRenderer().method_3166(itemstack, class_811.field_4319, poseStack, bufferSource, i, 0);

            poseStack.method_22909();
        }
    }
}
