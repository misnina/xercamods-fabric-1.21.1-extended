package xerca.xercapaint.client;

import net.minecraft.class_1101;
import net.minecraft.class_1113;
import net.minecraft.class_3419;
import xerca.xercapaint.SoundEvents;

@net.fabricmc.api.Environment(net.fabricmc.api.EnvType.CLIENT)
public class BrushSound extends class_1101 {
    private int age;
    private int fadingTicks = 4;

    private static final float[] FADE_VOLUMES = {0.0f, 0.3f, 0.7f};

    public BrushSound() {
        super(SoundEvents.STROKE_LOOP, class_3419.field_15250, class_1113.method_43221());
        field_5442 = 1.0f;
        field_5441 = 1.0F;
        field_5446 = true;
        field_5440 = class_1114.field_5478;
    }

    public void stopSound() {
        age += 300;
    }

    public void refreshFade() {
        fadingTicks = 3;
        field_5442 = 1.0f;
    }

    @Override
    public void method_16896() {
        age++;
        if (fadingTicks <= 0 && age > 300) {
            this.method_24876();
        }
        if (fadingTicks >= 0) {
            if (fadingTicks < FADE_VOLUMES.length) {
                field_5442 = FADE_VOLUMES[fadingTicks];
            }
            fadingTicks--;
        }

        float randomPitchChange = 0.03f - field_38800.method_43057() * 0.06f;
        if (field_5441 >= 1.2f && randomPitchChange > 0.f) {
            randomPitchChange -= 0.03f;
        } else if (field_5441 <= 0.8f && randomPitchChange < 0.f) {
            randomPitchChange += 0.03f;
        }
        field_5441 += randomPitchChange;
    }
}

