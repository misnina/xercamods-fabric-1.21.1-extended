package xerca.xercapaint.client;

import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import xerca.xercapaint.CanvasType;
import xerca.xercapaint.entity.EntityEasel;
import xerca.xercapaint.item.ItemCanvas;

public class EaselModel extends class_583<EntityEasel> {
    private final class_630 bbMain;
    private final class_630 bottomBar;
    private final class_630 topBar;

    public EaselModel(class_630 model) {
        this.bbMain = model;
        this.bottomBar = model.method_32086("bottomBar");
        this.topBar = model.method_32086("topBar");
    }

    public static class_5607 createBodyLayer() {
        class_5609 meshDefinition = new class_5609();
        class_5610 partDefinition = meshDefinition.method_32111();

        partDefinition.method_32117("bb_main", class_5606.method_32108(),
                class_5603.method_32091(0.0f, 24.0f, 0.0f, 0.0f, 0.0f, 0.0f));

        partDefinition.method_32117("cube_r1", class_5606.method_32108()
                        .method_32101(12, 0).method_32097(-5.5f, -31.5f, -0.8f, 1.0f, 26.0f, 1.0f),
                class_5603.method_32091(5.0f, 24.0f, -5.0f, -0.2618f, 0.0f, 0.0f));

        partDefinition.method_32117("bottomBar", class_5606.method_32108()
                        .method_32101(0, 0).method_32097(-4.5f, -0.5f, -0.5f, 9.0f, 1.0f, 1.0f),
                class_5603.method_32091(0.0f, 16.1f, -4.0f, -0.2618f, 0.0f, 0.0f));

        partDefinition.method_32117("topBar", class_5606.method_32108()
                        .method_32101(2, 2).method_32097(-3.0f, -14.0f, -0.5f, 6.0f, 1.0f, 1.0f),
                class_5603.method_32091(0.0f, 16.75f, -4.0f, -0.2618f, 0.0f, 0.0f));

        partDefinition.method_32117("cube_r3", class_5606.method_32108()
                        .method_32101(8, 0).method_32097(-0.5f, -21.0f, -1.0f, 1.0f, 21.0f, 1.0f),
                class_5603.method_32091(0.0f, 24.0f, 6.0f, 0.2618f, 0.0f, 0.0f));

        partDefinition.method_32117("cube_r4", class_5606.method_32108()
                        .method_32101(4, 0).method_32097(0.0f, -29.0f, -1.0f, 1.0f, 29.0f, 1.0f),
                class_5603.method_32091(5.0f, 24.0f, -5.0f, -0.2618f, 0.0f, -0.1309f));

        partDefinition.method_32117("cube_r5", class_5606.method_32108()
                        .method_32101(0, 0).method_32097(-1.0f, -29.0f, -1.0f, 1.0f, 29.0f, 1.0f),
                class_5603.method_32091(-5.0f, 24.0f, -5.0f, -0.2618f, 0.0f, 0.1309f));

        return class_5607.method_32110(meshDefinition, 16, 32);
    }

    @Override
    public void setupAnim(EntityEasel entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        if (entity.getItem().method_7909() instanceof ItemCanvas itemCanvas) {
            if (itemCanvas.getCanvasType() == CanvasType.LONG) {
                bottomBar.field_3656 = 13.5f;
                bottomBar.field_3655 = -3.25f;
                topBar.field_3656 = 16.25f;
                topBar.field_3655 = -4.0f;
                return;
            }
            if (itemCanvas.getCanvasType() == CanvasType.LARGE || itemCanvas.getCanvasType() == CanvasType.TALL) {
                bottomBar.field_3656 = 16.6f;
                bottomBar.field_3655 = -4.0f;
                topBar.field_3656 = 9.8f;
                topBar.field_3655 = -2.25f;
                return;
            }
            else {
                bottomBar.field_3656 = 16.6f;
                bottomBar.field_3655 = -4.0f;
                topBar.field_3656 = 9.8f;
                topBar.field_3655 = -2.25f;
                return;
            }
        }

        // Default values
        bottomBar.field_3656 = 16.1f;
        bottomBar.field_3655 = -4.0f;
        topBar.field_3656 = 16.75f;
        topBar.field_3655 = -4.0f;
    }

    @Override
    public void method_2828(class_4587 poseStack, class_4588 buffer, int packedLight, int packedOverlay, int color) {
        bbMain.method_22698(poseStack, buffer, packedLight, packedOverlay);
    }
}
