package xerca.xercapaint.client;

import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import xerca.xercapaint.CanvasSides;
import xerca.xercapaint.CanvasType;
import xerca.xercapaint.entity.EntityEasel;
import xerca.xercapaint.item.Items;

import java.util.List;
import net.minecraft.class_1074;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4588;

@net.fabricmc.api.Environment(net.fabricmc.api.EnvType.CLIENT)
public class GuiCanvasView extends class_437 {
    private int canvasX;
    private int canvasY = 50;
    private final int canvasWidth;
    private final int canvasPixelScale;
    private final int canvasPixelWidth;
    private final int canvasPixelHeight;
    private final CanvasType canvasType;
    private final boolean glass;

    private int @Nullable [] pixels;
    private final boolean sidesActive;
    private int @Nullable [] sidePixels;
    private @Nullable String authorName = "";
    private String canvasTitle = "";
    private int generation;
    private final @Nullable EntityEasel easel;
    private final @Nullable class_1657 player;

    protected GuiCanvasView(class_1799 canvasStack, class_2561 title, CanvasType canvasType, boolean glass, @Nullable EntityEasel easel) {
        super(title);

        this.canvasType = canvasType;
        this.glass = glass;
        if (canvasType == CanvasType.SMALL) {
            this.canvasPixelScale = 10;
        } else if (canvasType == CanvasType.EXTRA_LARGE || canvasType == CanvasType.EXTRA_TALL || canvasType == CanvasType.EXTRA_LONG) {
            this.canvasPixelScale = 3;
        } else {
            this.canvasPixelScale = 5;
        }
        this.canvasPixelWidth = CanvasType.getWidth(canvasType);
        this.canvasPixelHeight = CanvasType.getHeight(canvasType);
        this.canvasWidth = this.canvasPixelWidth * this.canvasPixelScale;
        this.easel = easel;
        this.player = class_310.method_1551().field_1724;

        List<Integer> stackPixels = canvasStack.method_57824(Items.CANVAS_PIXELS);
        if (stackPixels != null) {
            this.authorName = canvasStack.method_57824(Items.CANVAS_AUTHOR);
            this.canvasTitle = canvasStack.method_57825(Items.CANVAS_TITLE, "");
            this.generation = canvasStack.method_57825(Items.CANVAS_GENERATION, 0);

            this.pixels = stackPixels.stream().mapToInt(i -> i).toArray();
        }

        this.sidesActive = canvasStack.method_57825(Items.CANVAS_SIDES_ACTIVE, false);
        List<Integer> stackSidePixels = canvasStack.method_57824(Items.CANVAS_SIDE_PIXELS);
        if (stackSidePixels != null && stackSidePixels.size() == CanvasSides.count(canvasType)) {
            this.sidePixels = stackSidePixels.stream().mapToInt(i -> i).toArray();
        }
    }

    private int getSidePixel(int index) {
        if (sidePixels != null && index >= 0 && index < sidePixels.length) {
            return sidePixels[index];
        }
        return CanvasSides.DEFAULT_COLOR;
    }

    @Override
    public void method_25426() {
        canvasX = (this.field_22789 - canvasWidth) / 2;
        if (canvasType == CanvasType.LONG) {
            canvasY += 40;
        }
    }

    private int getPixelAt(int x, int y) {
        return (this.pixels == null) ? 0xFFF9FFFE : this.pixels[y * canvasPixelWidth + x];
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final int CHECKER_LIGHT = 0xFFBFBFBF;
    private static final int CHECKER_DARK = 0xFF7F7F7F;

    /**
     * Writes one coloured quad into the shared GUI buffer, like {@link class_332#method_25294} but without flushing.
     */
    private static void batchFill(class_4588 buffer, Matrix4f matrix, int x1, int y1, int x2, int y2, int color) {
        buffer.method_22918(matrix, x1, y1, 0.0f).method_39415(color);
        buffer.method_22918(matrix, x1, y2, 0.0f).method_39415(color);
        buffer.method_22918(matrix, x2, y2, 0.0f).method_39415(color);
        buffer.method_22918(matrix, x2, y1, 0.0f).method_39415(color);
    }

    private void fillChecker(class_4588 buffer, Matrix4f matrix, int x, int y, int parity) {
        batchFill(buffer, matrix, x, y, x + canvasPixelScale, y + canvasPixelScale, (parity & 1) == 0 ? CHECKER_LIGHT : CHECKER_DARK);
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float f) {
        // Write cells straight into the shared GUI buffer (guiGraphics.fill flushes per quad and tanks the FPS)
        Matrix4f matrix = guiGraphics.method_51448().method_23760().method_23761();
        class_4588 buffer = guiGraphics.method_51450().getBuffer(class_1921.method_51784());

        if (glass) {
            for (int i = 0; i < canvasPixelHeight; i++) {
                for (int j = 0; j < canvasPixelWidth; j++) {
                    fillChecker(buffer, matrix, canvasX + j * canvasPixelScale, canvasY + i * canvasPixelScale, i + j);
                }
            }
        }

        for (int i = 0; i < canvasPixelHeight; i++) {
            for (int j = 0; j < canvasPixelWidth; j++) {
                int x = canvasX + j * canvasPixelScale;
                int y = canvasY + i * canvasPixelScale;
                batchFill(buffer, matrix, x, y, x + canvasPixelScale, y + canvasPixelScale, getPixelAt(j, i));
            }
        }

        if (sidesActive) {
            int scale = canvasPixelScale;
            int canvasHeight = canvasPixelHeight * scale;
            for (int k = 0; k < canvasPixelWidth; k++) {
                int x = canvasX + k * scale;
                if (glass) {
                    fillChecker(buffer, matrix, x, canvasY - scale, k - 1);
                    fillChecker(buffer, matrix, x, canvasY + canvasHeight, k + canvasPixelHeight);
                }
                batchFill(buffer, matrix, x, canvasY - scale, x + scale, canvasY, getSidePixel(CanvasSides.topOffset() + k));
                batchFill(buffer, matrix, x, canvasY + canvasHeight, x + scale, canvasY + canvasHeight + scale, getSidePixel(CanvasSides.bottomOffset(canvasType) + k));
            }
            for (int i = 0; i < canvasPixelHeight; i++) {
                int y = canvasY + i * scale;
                if (glass) {
                    fillChecker(buffer, matrix, canvasX - scale, y, i - 1);
                    fillChecker(buffer, matrix, canvasX + canvasWidth, y, i + canvasPixelWidth);
                }
                batchFill(buffer, matrix, canvasX - scale, y, canvasX, y + scale, getSidePixel(CanvasSides.leftOffset(canvasType) + i));
                batchFill(buffer, matrix, canvasX + canvasWidth, y, canvasX + canvasWidth + scale, y + scale, getSidePixel(CanvasSides.rightOffset(canvasType) + i));
            }
        }

        if (generation > 0 && !canvasTitle.isEmpty()) {
            String title = canvasTitle + " " + class_1074.method_4662("canvas.byAuthor", authorName);
            String gen = "(" + class_1074.method_4662("canvas.generation." + (generation - 1)) + ")";

            int titleWidth = this.field_22793.method_1727(title);
            int genWidth = this.field_22793.method_1727(gen);

            float titleX = (canvasX + (canvasWidth - titleWidth) / 2.0f);
            float genX = (canvasX + (canvasWidth - genWidth) / 2.0f);
            float minX = Math.min(genX, titleX);
            float maxX = Math.max(genX + genWidth, titleX + titleWidth);

            guiGraphics.method_25294((int) (minX - 10), canvasY - 40, (int) (maxX + 10), canvasY - 14, 0xFFEEEEEE);

            guiGraphics.method_51433(field_22793, title, (int) titleX, (canvasY - 35), 0xFF111111, false);
            guiGraphics.method_51433(field_22793, gen, (int) genX, canvasY - 24, 0xFF444444, false);
        }
    }

    @Override
    public void method_25393() {
        if (easel != null && player != null
                && (easel.getItem().method_7960() || easel.method_31481() || easel.method_5858(player) > 64)) {
            this.method_25419();
        }
        super.method_25393();
    }
}
