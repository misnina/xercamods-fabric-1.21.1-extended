package xerca.xercapaint.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5272;
import net.minecraft.class_5601;
import net.minecraft.class_6395;
import org.jetbrains.annotations.Nullable;
import xerca.xercapaint.Mod;
import xerca.xercapaint.entity.Entities;
import xerca.xercapaint.entity.EntityEasel;
import xerca.xercapaint.item.ItemCanvas;
import xerca.xercapaint.item.ItemPalette;
import xerca.xercapaint.item.Items;
import xerca.xercapaint.packets.*;

@Environment(EnvType.CLIENT)
public class ModClient implements ClientModInitializer {
    public static final class_5601 EASEL_MAIN_LAYER = new class_5601(Mod.id("easel"), "main");
    public static final class_5601 EASEL_CANVAS_LAYER = new class_5601(Mod.id("easel"), "canvas");
    private static final String ITEM_CANVAS_TRANSLATION_KEY = "item.xercapaint.item_canvas";
    private static final String DRAWN_PREDICATE_ID = "drawn";
    private static @Nullable CanvasItemRenderer canvasItemRenderer;

    public static void showCanvasGui(EntityEasel easel, class_1799 palette) {
        showCanvasGui(easel, palette, class_310.method_1551());
    }

    public static void showCanvasGui(EntityEasel easel, class_1799 paletteStack, class_310 minecraft) {
        class_1799 canvasStack = easel.getItem();
        ItemCanvas canvasItem = (ItemCanvas) canvasStack.method_7909();
        if ((canvasStack.method_57825(Items.CANVAS_GENERATION, 0) > 0) || paletteStack.method_7960()) {
            minecraft.method_1507(new GuiCanvasView(canvasStack,
                    class_2561.method_43471(ITEM_CANVAS_TRANSLATION_KEY),
                    canvasItem.getCanvasType(), canvasItem.isGlass(), easel));
        } else {
            if (minecraft.field_1724 == null) {
                return;
            }
            minecraft.method_1507(new GuiCanvasEdit(minecraft.field_1724, canvasStack, paletteStack,
                    class_2561.method_43471(ITEM_CANVAS_TRANSLATION_KEY),
                    canvasItem.getCanvasType(), canvasItem.isGlass(), easel));
        }
    }

    public static void showCanvasGui(class_1657 player) {
        final class_1799 heldItem = player.method_6047();
        final class_1799 offhandItem = player.method_6079();
        final class_310 minecraft = class_310.method_1551();

        if (heldItem.method_7960() || (minecraft.field_1724 != null && !minecraft.field_1724.method_7334().getId().equals(player.method_7334().getId()))) {
            return;
        }

        if (heldItem.method_7909() instanceof ItemCanvas itemCanvas) {
            if (offhandItem.method_7960() || !(offhandItem.method_7909() instanceof ItemPalette) || (heldItem.method_57825(Items.CANVAS_GENERATION, 0) > 0)) {
                minecraft.method_1507(new GuiCanvasView(heldItem, class_2561.method_43471(ITEM_CANVAS_TRANSLATION_KEY), itemCanvas.getCanvasType(), itemCanvas.isGlass(), null));
            } else {
                minecraft.method_1507(new GuiCanvasEdit(minecraft.field_1724, heldItem, offhandItem, class_2561.method_43471(ITEM_CANVAS_TRANSLATION_KEY), itemCanvas.getCanvasType(), itemCanvas.isGlass(), null));
            }
        } else if (heldItem.method_7909() instanceof ItemPalette) {
            if (offhandItem.method_7960() || !(offhandItem.method_7909() instanceof ItemCanvas offhandCanvas)) {
                minecraft.method_1507(new GuiPalette(heldItem, class_2561.method_43471("item.xercapaint.item_palette")));
            } else {
                if (offhandItem.method_57825(Items.CANVAS_GENERATION, 0) > 0) {
                    minecraft.method_1507(new GuiCanvasView(offhandItem, class_2561.method_43471(ITEM_CANVAS_TRANSLATION_KEY), offhandCanvas.getCanvasType(), offhandCanvas.isGlass(), null));
                } else {
                    minecraft.method_1507(new GuiCanvasEdit(minecraft.field_1724, offhandItem, heldItem, class_2561.method_43471(ITEM_CANVAS_TRANSLATION_KEY), offhandCanvas.getCanvasType(), offhandCanvas.isGlass(), null));
                }
            }
        }
    }

    static CanvasItemRenderer requireCanvasItemRenderer() {
        if (canvasItemRenderer == null) {
            throw new IllegalStateException("Canvas item renderer not initialized");
        }
        return canvasItemRenderer;
    }

    @Override
    public void onInitializeClient() {
        canvasItemRenderer = new CanvasItemRenderer(class_310.method_1551().method_31975(), class_310.method_1551().method_31974());
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_LARGE, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_LONG, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_TALL, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_EXTRA_LARGE, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_EXTRA_LONG, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_EXTRA_TALL, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_SUPER_LARGE, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_SUPER_LONG, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_SUPER_TALL, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_GLASS, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_GLASS_LARGE, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_GLASS_LONG, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_GLASS_TALL, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_GLASS_EXTRA_LARGE, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_GLASS_EXTRA_LONG, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_GLASS_EXTRA_TALL, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_GLASS_SUPER_LARGE, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_GLASS_SUPER_LONG, canvasItemRenderer);
        BuiltinItemRendererRegistry.INSTANCE.register(Items.ITEM_CANVAS_GLASS_SUPER_TALL, canvasItemRenderer);

        EntityRendererRegistry.register(Entities.EASEL, new RenderEntityEasel.RenderEntityEaselFactory());
        EntityRendererRegistry.register(Entities.CANVAS, new RenderEntityCanvas.RenderEntityCanvasFactory());
        EntityModelLayerRegistry.registerModelLayer(EASEL_MAIN_LAYER, EaselModel::createBodyLayer);
        EntityModelLayerRegistry.registerModelLayer(EASEL_CANVAS_LAYER, EaselModel::createBodyLayer);

        class_6395 drawn = (itemStack, level, livingEntity, i) -> {
            if (itemStack.method_57824(Items.CANVAS_PIXELS) == null) return 0.0f;
            else return 1.0F;
        };
        class_6395 colors = (stack, worldIn, entityIn, i) ->
                ItemPalette.basicColorCount(stack) / 16.0F;
        class_5272.method_27879(Items.ITEM_CANVAS, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_LARGE, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_LONG, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_TALL, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_EXTRA_LARGE, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_EXTRA_LONG, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_EXTRA_TALL, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_SUPER_LARGE, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_SUPER_LONG, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_SUPER_TALL, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_GLASS, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_GLASS_LARGE, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_GLASS_LONG, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_GLASS_TALL, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_GLASS_EXTRA_LARGE, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_GLASS_EXTRA_LONG, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_GLASS_EXTRA_TALL, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_GLASS_SUPER_LARGE, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_GLASS_SUPER_LONG, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_CANVAS_GLASS_SUPER_TALL, Mod.id(DRAWN_PREDICATE_ID), drawn);
        class_5272.method_27879(Items.ITEM_PALETTE, Mod.id("colors"), colors);

        ClientPlayNetworking.registerGlobalReceiver(CloseGuiPacket.PACKET_ID, new CloseGuiPacketHandler());
        ClientPlayNetworking.registerGlobalReceiver(ExportPaintingPacket.PACKET_ID, new ExportPaintingPacketHandler());
        ClientPlayNetworking.registerGlobalReceiver(ImportPaintingPacket.PACKET_ID, new ImportPaintingPacketHandler());
        ClientPlayNetworking.registerGlobalReceiver(OpenGuiPacket.PACKET_ID, new OpenGuiPacketHandler());
        ClientPlayNetworking.registerGlobalReceiver(PictureSendPacket.PACKET_ID, new PictureSendPacketHandler());
    }
}
