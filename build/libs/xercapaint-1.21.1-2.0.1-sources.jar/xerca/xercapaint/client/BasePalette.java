package xerca.xercapaint.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1109;
import net.minecraft.class_1113;
import net.minecraft.class_1799;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_437;
import org.jetbrains.annotations.Nullable;
import xerca.xercapaint.Mod;
import xerca.xercapaint.PaletteUtil;
import xerca.xercapaint.SoundEvents;
import xerca.xercapaint.item.ItemPalette;
import xerca.xercapaint.item.Items;

import static xerca.xercapaint.PaletteUtil.EMPTINESS_COLOR;

public abstract class BasePalette extends class_437 {
    protected static final class_2960 PALETTE_TEXTURES = Mod.id("textures/gui/palette.png");
    static final int DYE_SPRITE_X = 240;
    static final int DYE_SPRITE_SIZE = 16;
    static final int BRUSH_SPRITE_X = 0;
    static final int BRUSH_SPRITE_Y = 247;
    static final int BRUSH_SPRITE_SIZE = 9;
    static final int BRUSH_OPACITY_SPRITE_X = 196;
    static final int BRUSH_OPACITY_SPRITE_Y = 197;
    static final int BRUSH_OPACITY_SPRITE_SIZE = 14;
    static final int DROP_SPRITE_WIDTH = 6;
    static final int PALETTE_WIDTH = 157;
    static final int PALETTE_HEIGHT = 193;
    static final int COLOR_PICKER_SPRITE_X = 25;
    static final int COLOR_PICKER_SPRITE_Y = 242;
    static final int COLOR_PICKER_POS_X = 98;
    static final int COLOR_PICKER_POS_Y = 62;
    static final int COLOR_PICKER_SIZE = 14;

    // PALETTE_XS and YS are the X and Y starting point of the GUI based upon the number of Canvas sizes in CanvasType.
    // The GUI will glitch and crash if the canvas type doesn't start fully within the screen.
    static final double[] PALETTE_XS = {-1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000};
    static final double[] PALETTE_YS = {-1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000};
    double paletteX;
    double paletteY;
    static final PaletteUtil.Color WATER_COLOR = new PaletteUtil.Color(53, 118, 191);

    static final PaletteUtil.Color[] BASIC_COLORS = {
            new PaletteUtil.Color(0xFF1D1D21),
            new PaletteUtil.Color(0xFFB02E26),
            new PaletteUtil.Color(0xFF5E7C16),
            new PaletteUtil.Color(0xFF835432),
            new PaletteUtil.Color(0xFF3C44AA),
            new PaletteUtil.Color(0xFF8932B8),
            new PaletteUtil.Color(0xFF169C9C),
            new PaletteUtil.Color(0xFF9D9D97),
            new PaletteUtil.Color(0xFF474F52),
            new PaletteUtil.Color(0xFFF38BAA),
            new PaletteUtil.Color(0xFF80C71F),
            new PaletteUtil.Color(0xFFFED83D),
            new PaletteUtil.Color(0xFF3AB3DA),
            new PaletteUtil.Color(0xFFC74EBD),
            new PaletteUtil.Color(0xFFF9801D),
            new PaletteUtil.Color(0xFFF9FFFE)
    };
    static final class_241[] BASIC_COLOR_CENTERS = {
            new class_241(23.5f, 172.5f),
            new class_241(18.5f, 145.5f),
            new class_241(16.5f, 117.5f),
            new class_241(17.5f, 89.5f),
            new class_241(23.5f, 62.5f),
            new class_241(38.5f, 39.5f),
            new class_241(61.5f, 24.5f),
            new class_241(87.5f, 17.5f),
            new class_241(114.5f, 15.5f),
            new class_241(44.5f, 154.5f),
            new class_241(41.5f, 127.5f),
            new class_241(42.5f, 100.5f),
            new class_241(48.5f, 74.5f),
            new class_241(64.5f, 52.5f),
            new class_241(90.5f, 44.5f),
            new class_241(117.5f, 42.5f)
    };
    static final class_241[] CUSTOM_COLOR_CENTERS = {
            new class_241(101.5f, 132.0f),
            new class_241(113.5f, 118.0f),
            new class_241(120.5f, 102.0f),
            new class_241(124.5f, 084.0f),
            new class_241(126.5f, 066.0f),
            new class_241(097.5f, 152.0f),
            new class_241(114.5f, 146.0f),
            new class_241(127.5f, 133.0f),
            new class_241(134.5f, 116.0f),
            new class_241(139.5f, 098.0f),
            new class_241(142.5f, 080.0f),
            new class_241(144.5f, 062.0f),
    };
    static final class_241 WATER_CENTER = new class_241(140.5f, 28.f);
    static final float BASIC_COLOR_RADIUS = 11.f;
    static final float CUSTOM_COLOR_RADIUS = 6.5f;

    boolean isPickingColor;
    boolean isCarryingColor;
    boolean isCarryingWater;
    boolean canvasDirty;
    boolean paletteDirty;
    @Nullable PaletteUtil.Color carriedColor;
    int carriedCustomColorId = -1;
    // Static so the last picked color is remembered across GUI openings
    static PaletteUtil.Color currentColor = BASIC_COLORS[0];
    final PaletteUtil.CustomColor[] customColors;
    final boolean[] basicColorFlags;
    boolean paletteComplete;
    boolean isCarryingPalette;

    BasePalette(class_2561 titleIn, class_1799 paletteStack) {
        super(titleIn);
        this.basicColorFlags = new boolean[16];

        ItemPalette.ComponentCustomColor componentCustomColor = paletteStack.method_57824(Items.PALETTE_CUSTOM_COLORS);
        if (componentCustomColor != null) {
            this.customColors = componentCustomColor.colors;
        } else {
            this.customColors = new PaletteUtil.CustomColor[12];
            for (int i = 0; i < customColors.length; i++) {
                customColors[i] = new PaletteUtil.CustomColor();
            }
        }

        byte[] basics = paletteStack.method_57824(Items.PALETTE_BASIC_COLORS);
        if (basics != null) {
            paletteComplete = true;
            for (int i = 0; i < basics.length; i++) {
                basicColorFlags[i] = basics[i] > 0;
                paletteComplete &= basicColorFlags[i];
            }
        }
    }

    protected void superRender(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTicks);
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTicks);

        RenderSystem.setShaderTexture(0, PALETTE_TEXTURES);

        // Draw basic colors
        for (int i = 0; i < basicColorFlags.length; i++) {
            int x = (int) paletteX + (int) BASIC_COLOR_CENTERS[i].field_1343;
            int y = (int) paletteY + (int) BASIC_COLOR_CENTERS[i].field_1342;
            int r = (int) BASIC_COLOR_RADIUS;
            if (basicColorFlags[i]) {
                guiGraphics.method_25294(x - r, y - r, x + r + 1, y + r + 1, BASIC_COLORS[i].rgbVal());

                RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
                guiGraphics.method_25302(PALETTE_TEXTURES, x - 8, y - 8, DYE_SPRITE_X, i * DYE_SPRITE_SIZE, DYE_SPRITE_SIZE, DYE_SPRITE_SIZE);
            } else {
                guiGraphics.method_25294(x - r, y - r, x + r + 1, y + r + 1, EMPTINESS_COLOR.rgbVal());
            }
        }

        // Draw custom colors
        for (int i = 0; i < customColors.length; i++) {
            int x = (int) paletteX + (int) CUSTOM_COLOR_CENTERS[i].field_1343;
            int y = (int) paletteY + (int) CUSTOM_COLOR_CENTERS[i].field_1342;
            guiGraphics.method_25294(x - 6, y - 7, x + 7, y + 6, customColors[i].getColor().rgbVal());
        }

        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        guiGraphics.method_25302(PALETTE_TEXTURES, (int) paletteX, (int) paletteY, 0, 0, PALETTE_WIDTH, PALETTE_HEIGHT);

        // Draw color picker
        if (paletteComplete) {
            guiGraphics.method_25302(PALETTE_TEXTURES, (int) paletteX + COLOR_PICKER_POS_X, (int) paletteY + COLOR_PICKER_POS_Y, COLOR_PICKER_SPRITE_X, COLOR_PICKER_SPRITE_Y, COLOR_PICKER_SIZE, COLOR_PICKER_SIZE);
        }
    }

    protected boolean superMouseClicked(double posX, double posY, int mouseButton) {
        return super.method_25402(posX, posY, mouseButton);
    }

    protected boolean superMouseReleased(double posX, double posY, int mouseButton) {
        return super.method_25406(posX, posY, mouseButton);
    }

    protected boolean superMouseDragged(double posX, double posY, int mouseButton, double deltaX, double deltaY) {
        return super.method_25403(posX, posY, mouseButton, deltaX, deltaY);
    }

    // Mouse button 0: left, 1: right
    @Override
    public boolean method_25402(double posX, double posY, int mouseButton) {
        int mouseX = (int) Math.round(posX);
        int mouseY = (int) Math.round(posY);

        if (paletteClick(mouseX, mouseY)) {
            int x = (mouseX - (int) paletteX);
            int y = (mouseY - (int) paletteY);
            class_241 clickVec = new class_241(x, y);
            float sqrBasicRadius = BASIC_COLOR_RADIUS * BASIC_COLOR_RADIUS;
            float sqrCustomRadius = CUSTOM_COLOR_RADIUS * CUSTOM_COLOR_RADIUS;

            boolean didSomething = false;
            for (int i = 0; i < BASIC_COLOR_CENTERS.length; i++) {
                if (basicColorFlags[i] && sqrDist(clickVec, BASIC_COLOR_CENTERS[i]) <= sqrBasicRadius) {
                    if (mouseButton == 0) {
                        carriedColor = currentColor = BASIC_COLORS[i];
                        setCarryingColor();
                        playSound(SoundEvents.MIX, 0.6f);
                    }
                    didSomething = true;
                    break;
                }
            }

            if (!didSomething) {
                for (int i = 0; i < CUSTOM_COLOR_CENTERS.length; i++) {
                    if (sqrDist(clickVec, CUSTOM_COLOR_CENTERS[i]) <= sqrCustomRadius) {
                        if (mouseButton == 0 && customColors[i].getNumberOfColors() > 0) {
                            carriedColor = currentColor = customColors[i].getColor();
                            carriedCustomColorId = i;
                            setCarryingColor();
                            playSound(SoundEvents.MIX, 0.3f);
                        }
                        didSomething = true;
                        break;
                    }
                }
            }

            if (!didSomething && sqrDist(clickVec, WATER_CENTER) <= sqrCustomRadius && mouseButton == 0) {
                setCarryingWater();
                playSound(SoundEvents.WATER);
                didSomething = true;
            }

            if (!didSomething && paletteComplete && !isCarryingWater && !isCarryingColor && inColorPicker(x, y) && mouseButton == 0) {
                setPickingColor();
                playSound(SoundEvents.COLOR_PICKER);
                didSomething = true;
            }

            if (!didSomething) {
                isCarryingPalette = true;
            }
        }
        return super.method_25402(mouseX, mouseY, mouseButton);
    }

    protected boolean inColorPicker(int x, int y) {
        return x >= COLOR_PICKER_POS_X && x < COLOR_PICKER_POS_X + COLOR_PICKER_SIZE && y >= COLOR_PICKER_POS_Y && y < COLOR_PICKER_POS_Y + COLOR_PICKER_SIZE;
    }

    protected boolean inWater(int x, int y) {
        return sqrDist(new class_241(x, y), WATER_CENTER) <= CUSTOM_COLOR_RADIUS * CUSTOM_COLOR_RADIUS;
    }

    protected void setCarryingWater() {
        isCarryingWater = true;
        isCarryingColor = false;
        isPickingColor = false;
    }

    protected void setCarryingColor() {
        isCarryingWater = false;
        isCarryingColor = true;
        isPickingColor = false;
    }

    protected void setPickingColor() {
        isCarryingWater = false;
        isCarryingColor = false;
        isPickingColor = true;
    }

    @Override
    public boolean method_25406(double posX, double posY, int mouseButton) {
        int mouseX = (int) Math.round(posX);
        int mouseY = (int) Math.round(posY);
        if (isCarryingColor || isCarryingWater) {
            if (paletteClick(mouseX, mouseY)) {
                float sqrCustomRadius = CUSTOM_COLOR_RADIUS * CUSTOM_COLOR_RADIUS;
                int x = (mouseX - (int) paletteX);
                int y = (mouseY - (int) paletteY);
                class_241 clickVec = new class_241(x, y);
                for (int i = 0; i < CUSTOM_COLOR_CENTERS.length; i++) {
                    if (sqrDist(clickVec, CUSTOM_COLOR_CENTERS[i]) <= sqrCustomRadius) {
                        PaletteUtil.CustomColor customColor = customColors[i];
                        if (isCarryingWater) {
                            customColor.reset();
                            playSound(SoundEvents.WATER_DROP);
                        } else {
                            if (carriedCustomColorId != i && carriedColor != null) {
                                customColor.mix(carriedColor);
                                currentColor = customColor.getColor();
                                playSound(SoundEvents.MIX);
                            }
                        }
                        paletteDirty = true;
                        break;
                    }
                }
            }
            isCarryingColor = false;
            isCarryingWater = false;
            carriedCustomColorId = -1;
        }
        isCarryingPalette = false;
        return super.method_25406(posX, posY, mouseButton);
    }

    protected void playSound(class_1113 sound) {
        class_310.method_1551().method_1483().method_4873(sound);
    }

    protected void playSound(class_3414 soundEvent) {
        playSound(soundEvent, 1.0f);
    }

    protected void playSound(class_3414 soundEvent, float volume) {
        class_310 m = class_310.method_1551();
        if (m.field_1687 != null && m.field_1724 != null) {
            m.method_1483().method_4873(new class_1109(soundEvent, class_3419.field_15250, volume,
                    0.8f + m.field_1687.field_9229.method_43057() * 0.4f, m.field_1724.method_59922(), m.field_1724.method_24515()));
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    boolean paletteClick(int x, int y) {
        return x <= paletteX + PALETTE_WIDTH && x >= paletteX && y <= paletteY + PALETTE_HEIGHT && y >= paletteY;
    }

    float sqrDist(class_241 a, class_241 b) {
        return (a.field_1343 - b.field_1343) * (a.field_1343 - b.field_1343) + (a.field_1342 - b.field_1342) * (a.field_1342 - b.field_1342);
    }
}
