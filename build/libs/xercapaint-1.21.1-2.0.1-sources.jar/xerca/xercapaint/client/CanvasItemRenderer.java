package xerca.xercapaint.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5599;
import net.minecraft.class_756;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_824;
import org.joml.Matrix4f;
import xerca.xercapaint.Mod;
import xerca.xercapaint.CanvasType;
import xerca.xercapaint.item.ItemCanvas;
import xerca.xercapaint.item.Items;

public class CanvasItemRenderer extends class_756 implements BuiltinItemRendererRegistry.DynamicItemRenderer {
    private static final class_2960 BACK_LOCATION = class_2960.method_60655("minecraft", "textures/block/birch_planks.png");
    private static final class_2960 EMPTY_CANVAS_LOCATION = Mod.id("textures/block/empty.png");
    private static final class_2960 GLASS_FRAME_LOCATION = class_2960.method_60655("minecraft", "textures/block/glass.png");
    private static final int GLASS_INVENTORY_TINT = 0xFFDCE6FF;

    public CanvasItemRenderer(class_824 dispatcher, class_5599 entityModelSet) {
        super(dispatcher, entityModelSet);
    }

    @Override
    public void method_3166(class_1799 stack, class_811 displayContext, class_4587 matrixStack, class_4597 buffer, int combinedLight, int combinedOverlay) {
        if (stack.method_7909() instanceof ItemCanvas itemCanvas) {
            boolean rendered = false;
            if (stack.method_57824(Items.CANVAS_PIXELS) != null && RenderEntityCanvas.theInstance != null) {
                RenderEntityCanvas.Instance canvasIns = RenderEntityCanvas.theInstance.getCanvasRendererInstance(stack, itemCanvas.getWidth(), itemCanvas.getHeight(), CanvasType.getWidth(itemCanvas.getCanvasType()), CanvasType.getHeight(itemCanvas.getCanvasType()));
                if (canvasIns != null) {
                    int tint = (itemCanvas.isGlass() && displayContext == class_811.field_4317) ? GLASS_INVENTORY_TINT : RenderEntityCanvas.NO_TINT;
                    canvasIns.render(null, 0, 0, matrixStack, buffer, class_2350.field_11036, combinedLight, itemCanvas.isGlass(), tint);
                    rendered = true;
                }
            }

            // Originally itemCanvas.getHeigth() and width.
            // Sets the size of a non-painted canvas an easle entity, based on the item entity size but needs to be canvas type size for extra large.
            if (!rendered) {
                renderEmptyCanvas(matrixStack, buffer, CanvasType.getWidth(itemCanvas.getCanvasType()), CanvasType.getHeight(itemCanvas.getCanvasType()), combinedLight, itemCanvas.isGlass());
            }
        }
    }

    private void addVertex(class_4588 vb, Matrix4f m, class_4587.class_4665 pose, double x, double y, double z, float tx, float ty, int lightmap, float xOff, float yOff, float zOff) {
        vb.method_22918(m, (float) x, (float) y, (float) z).method_1336(255, 255, 255, 255).method_22913(tx, ty).method_22922(class_4608.field_21444).method_60803(lightmap).method_60831(pose, xOff, yOff, zOff);
    }

    private void renderEmptyCanvas(class_4587 ms, class_4597 buffer, float width, float height, int packedLight, boolean glass) {
        final float wScale = width / 16.0f;
        final float hScale = height / 16.0f;

        ms.method_22903();

        float f = 1.0f / 32.0f;
        ms.method_22904(0.75, 0.5, 0.5);
        if (wScale > 1 || hScale > 1) {
            f /= 3.3f;
        } else {
            f /= 2.0f;
        }

        ms.method_22907(class_7833.field_40716.rotationDegrees(180));

        ms.method_22905(f, f, f);

        Matrix4f m = ms.method_23760().method_23761();
        class_4587.class_4665 pose = ms.method_23760();

        final float w32 = 32.0F * wScale;
        final float h32 = 32.0F * hScale;

        if (glass) {
            // Empty glass canvas: transparent front and back, only the glass-pane frame on the edges
            renderGlassFrame(buffer, m, pose, w32, h32, packedLight);
            ms.method_22909();
            return;
        }

        RenderSystem.setShaderTexture(0, EMPTY_CANVAS_LOCATION);

        class_4588 vb = buffer.getBuffer(class_1921.method_23572(EMPTY_CANVAS_LOCATION));

        // Draw the front (normal -Z)
        addVertex(vb, m, pose, 0.0F, h32, -1.0F, 1.0F, 0.0F, packedLight, 0.0F, 0.0F, -1.0F);
        addVertex(vb, m, pose, w32, h32, -1.0F, 0.0F, 0.0F, packedLight, 0.0F, 0.0F, -1.0F);
        addVertex(vb, m, pose, w32, 0.0F, -1.0F, 0.0F, 1.0F, packedLight, 0.0F, 0.0F, -1.0F);
        addVertex(vb, m, pose, 0.0F, 0.0F, -1.0F, 1.0F, 1.0F, packedLight, 0.0F, 0.0F, -1.0F);

        vb = buffer.getBuffer(class_1921.method_23572(BACK_LOCATION));
        // Draw the back and sides
        final float sideWidth = 1.0F / 16.0F;

        RenderSystem.setShaderTexture(0, BACK_LOCATION);
        // BACK (normal +Z)
        addVertex(vb, m, pose, 0.0D, 0.0D, 1.0D, 0.0F, 0.0F, packedLight, 0.0F, 0.0F, 1.0F);
        addVertex(vb, m, pose, w32, 0.0D, 1.0D, 1.0F, 0.0F, packedLight, 0.0F, 0.0F, 1.0F);
        addVertex(vb, m, pose, w32, h32, 1.0D, 1.0F, 1.0F, packedLight, 0.0F, 0.0F, 1.0F);
        addVertex(vb, m, pose, 0.0D, h32, 1.0D, 0.0F, 1.0F, packedLight, 0.0F, 0.0F, 1.0F);

        // LEFT SIDE (x = 0, normal -X)
        addVertex(vb, m, pose, 0.0D, 0.0D, 1.0D, sideWidth, 0.0F, packedLight, -1.0F, 0.0F, 0.0F);
        addVertex(vb, m, pose, 0.0D, h32, 1.0D, sideWidth, 1.0F, packedLight, -1.0F, 0.0F, 0.0F);
        addVertex(vb, m, pose, 0.0D, h32, -1.0D, 0.0F, 1.0F, packedLight, -1.0F, 0.0F, 0.0F);
        addVertex(vb, m, pose, 0.0D, 0.0D, -1.0D, 0.0F, 0.0F, packedLight, -1.0F, 0.0F, 0.0F);

        // TOP SIDE (y = h32, normal +Y)
        addVertex(vb, m, pose, 0.0D, h32, 1.0F, 0.0F, 0.0F, packedLight, 0.0F, 1.0F, 0.0F);
        addVertex(vb, m, pose, w32, h32, 1.0F, 1.0F, 0.0F, packedLight, 0.0F, 1.0F, 0.0F);
        addVertex(vb, m, pose, w32, h32, -1.0F, 1.0F, sideWidth, packedLight, 0.0F, 1.0F, 0.0F);
        addVertex(vb, m, pose, 0.0D, h32, -1.0F, 0.0F, sideWidth, packedLight, 0.0F, 1.0F, 0.0F);

        // RIGHT SIDE (x = w32, normal +X)
        addVertex(vb, m, pose, w32, 0.0D, -1.0F, 0.0F, 0.0F, packedLight, 1.0F, 0.0F, 0.0F);
        addVertex(vb, m, pose, w32, h32, -1.0F, 0.0F, 1.0F, packedLight, 1.0F, 0.0F, 0.0F);
        addVertex(vb, m, pose, w32, h32, 1.0F, sideWidth, 1.0F, packedLight, 1.0F, 0.0F, 0.0F);
        addVertex(vb, m, pose, w32, 0.0D, 1.0F, sideWidth, 0.0F, packedLight, 1.0F, 0.0F, 0.0F);

        // BOTTOM SIDE (y = 0, normal -Y)
        addVertex(vb, m, pose, 0.0D, 0.0D, -1.0F, 0.0F, 1.0F, packedLight, 0.0F, -1.0F, 0.0F);
        addVertex(vb, m, pose, w32, 0.0D, -1.0F, 1.0F, 1.0F, packedLight, 0.0F, -1.0F, 0.0F);
        addVertex(vb, m, pose, w32, 0.0D, 1.0F, 1.0F, 1.0F - sideWidth, packedLight, 0.0F, -1.0F, 0.0F);
        addVertex(vb, m, pose, 0.0D, 0.0D, 1.0F, 0.0F, 1.0F - sideWidth, packedLight, 0.0F, -1.0F, 0.0F);

        ms.method_22909();
    }

    /**
     * Renders the four glass-canvas edges using the vanilla glass-pane texture. Mirrors
     * renderGlassFramefor the empty-canvas item path.
     */
    private void renderGlassFrame(class_4597 buffer, Matrix4f m, class_4587.class_4665 pose, float w32, float h32, int packedLight) {
        RenderSystem.setShaderTexture(0, GLASS_FRAME_LOCATION);
        class_4588 vb = buffer.getBuffer(class_1921.method_23580(GLASS_FRAME_LOCATION));
        final double eps = 0.001;
        final float depth = 1.0F / 16.0F;
        // LEFT (x = 0, normal -X)
        addVertex(vb, m, pose, eps, eps, 1.0D, 0.0F, 0.0F, packedLight, -1.0F, 0.0F, 0.0F);
        addVertex(vb, m, pose, eps, h32 - eps, 1.0D, 0.0F, 1.0F, packedLight, -1.0F, 0.0F, 0.0F);
        addVertex(vb, m, pose, eps, h32 - eps, -1.0D, depth, 1.0F, packedLight, -1.0F, 0.0F, 0.0F);
        addVertex(vb, m, pose, eps, eps, -1.0D, depth, 0.0F, packedLight, -1.0F, 0.0F, 0.0F);
        // TOP (y = h32, normal +Y)
        addVertex(vb, m, pose, eps, h32 - eps, 1.0D, 0.0F, 0.0F, packedLight, 0.0F, 1.0F, 0.0F);
        addVertex(vb, m, pose, w32 - eps, h32 - eps, 1.0D, 1.0F, 0.0F, packedLight, 0.0F, 1.0F, 0.0F);
        addVertex(vb, m, pose, w32 - eps, h32 - eps, -1.0D, 1.0F, depth, packedLight, 0.0F, 1.0F, 0.0F);
        addVertex(vb, m, pose, eps, h32 - eps, -1.0D, 0.0F, depth, packedLight, 0.0F, 1.0F, 0.0F);
        // RIGHT (x = w32, normal +X)
        addVertex(vb, m, pose, w32 - eps, eps, -1.0D, 0.0F, 0.0F, packedLight, 1.0F, 0.0F, 0.0F);
        addVertex(vb, m, pose, w32 - eps, h32 - eps, -1.0D, 0.0F, 1.0F, packedLight, 1.0F, 0.0F, 0.0F);
        addVertex(vb, m, pose, w32 - eps, h32 - eps, 1.0D, depth, 1.0F, packedLight, 1.0F, 0.0F, 0.0F);
        addVertex(vb, m, pose, w32 - eps, eps, 1.0D, depth, 0.0F, packedLight, 1.0F, 0.0F, 0.0F);
        // BOTTOM (y = 0, normal -Y)
        addVertex(vb, m, pose, eps, eps, -1.0D, 0.0F, 0.0F, packedLight, 0.0F, -1.0F, 0.0F);
        addVertex(vb, m, pose, w32 - eps, eps, -1.0D, 1.0F, 0.0F, packedLight, 0.0F, -1.0F, 0.0F);
        addVertex(vb, m, pose, w32 - eps, eps, 1.0D, 1.0F, depth, packedLight, 0.0F, -1.0F, 0.0F);
        addVertex(vb, m, pose, eps, eps, 1.0D, 0.0F, depth, packedLight, 0.0F, -1.0F, 0.0F);
    }

    @Override
    public void render(class_1799 stack, class_811 displayContext, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        method_3166(stack, displayContext, matrices, vertexConsumers, light, overlay);
    }
}
