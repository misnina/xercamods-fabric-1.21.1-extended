package xerca.xercapaint.client;

import com.google.common.collect.Lists;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import xerca.xercapaint.Mod;
import xerca.xercapaint.entity.EntityEasel;
import xerca.xercapaint.item.ItemCanvas;

import java.util.List;
import net.minecraft.class_1921;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_3966;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;

@net.fabricmc.api.Environment(net.fabricmc.api.EnvType.CLIENT)
public class RenderEntityEasel extends class_897<EntityEasel> implements class_3883<EntityEasel, EaselModel> {
    protected final EaselModel model;
    protected final List<class_3887<EntityEasel, EaselModel>> layers = Lists.newArrayList();
    static @Nullable RenderEntityEasel theInstance;
    private static final class_2960 WOOD_TEXTURE = Mod.id("textures/block/birch_long.png");

    RenderEntityEasel(class_5617.class_5618 ctx) {
        super(ctx);
        this.model = new EaselModel(ctx.method_32167(ModClient.EASEL_MAIN_LAYER));
        this.layers.add(new EaselCanvasLayer(this));
    }

    @Override
    public EaselModel method_4038() {
        return this.model;
    }

    @Override
    public class_2960 getTextureLocation(EntityEasel entity) {
        return WOOD_TEXTURE;
    }

    @Override
    public void render(EntityEasel entity, float entityYaw, float partialTicks, class_4587 matrixStackIn, class_4597 bufferIn, int packedLightIn) {
        matrixStackIn.method_22903();

        matrixStackIn.method_22907(class_7833.field_40716.rotationDegrees(-entityYaw));

        this.model.setupAnim(entity, 0, 0, 0, 0, 0);

        matrixStackIn.method_22907(new Quaternionf().rotationXYZ((float) Math.PI, 0, 0));
        matrixStackIn.method_22904(0, -1.5, 0);

        class_1921 rendertype = this.model.method_23500(this.getTextureLocation(entity));
        class_4588 vertexconsumer = bufferIn.getBuffer(rendertype);

        int i = class_4608.method_23625(class_4608.method_23210(0), class_4608.method_23212(false));
        this.model.method_60879(matrixStackIn, vertexconsumer, packedLightIn, i);

        this.layers.forEach(renderLayer -> renderLayer.method_4199(matrixStackIn, bufferIn, packedLightIn, entity, 0, 0, 0, 0, 0, 0));

        matrixStackIn.method_22909();
        super.method_3936(entity, entityYaw, partialTicks, matrixStackIn, bufferIn, packedLightIn);
    }

    @Override
    protected boolean shouldShowName(EntityEasel easel) {
        class_239 result = class_310.method_1551().field_1765;
        if (result instanceof class_3966 entityHitResult && class_310.method_1498() && easel.equals(entityHitResult.method_17782()) && !easel.getItem().method_7960() && ItemCanvas.hasTitle(easel.getItem())) {
            double distanceSquared = this.field_4676.method_23168(easel);
            float range = easel.method_21751() ? 32.0F : 64.0F;
            return distanceSquared < range * range;
        }
        return false;
    }

    @Override
    protected void renderNameTag(EntityEasel easel, class_2561 displayName, class_4587 poseStack, class_4597 bufferSource, int packedLight, float partialTick) {
        poseStack.method_22903();
        poseStack.method_22904(0, -0.5, 0);
        super.method_3926(easel, ItemCanvas.getFullLabel(easel.getItem()), poseStack, bufferSource, packedLight, partialTick);
        poseStack.method_22909();
    }

    public static class RenderEntityEaselFactory implements class_5617<EntityEasel> {
        @Override
        public class_897<EntityEasel> create(class_5618 ctx) {
            RenderEntityEasel instance = new RenderEntityEasel(ctx);
            theInstance = instance;
            return instance;
        }
    }
}
