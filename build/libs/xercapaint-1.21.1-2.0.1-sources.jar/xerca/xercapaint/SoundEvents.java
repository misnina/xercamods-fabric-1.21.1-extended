package xerca.xercapaint;

import static net.minecraft.class_7923.field_41172;

import net.minecraft.class_2378;
import net.minecraft.class_3414;

public class SoundEvents {
    private SoundEvents() {
    }

    public static final class_3414 STROKE_LOOP = class_3414.method_47908(Mod.id("stroke_loop"));
    public static final class_3414 MIX = class_3414.method_47908(Mod.id("mix"));
    public static final class_3414 COLOR_PICKER = class_3414.method_47908(Mod.id("color_picker"));
    public static final class_3414 COLOR_PICKER_SUCK = class_3414.method_47908(Mod.id("color_picker_suck"));
    public static final class_3414 WATER = class_3414.method_47908(Mod.id("water"));
    public static final class_3414 WATER_DROP = class_3414.method_47908(Mod.id("water_drop"));

    public static void registerSoundEvents() {
        class_2378.method_10230(field_41172, STROKE_LOOP.method_14833(), STROKE_LOOP);
        class_2378.method_10230(field_41172, MIX.method_14833(), MIX);
        class_2378.method_10230(field_41172, COLOR_PICKER.method_14833(), COLOR_PICKER);
        class_2378.method_10230(field_41172, COLOR_PICKER_SUCK.method_14833(), COLOR_PICKER_SUCK);
        class_2378.method_10230(field_41172, WATER.method_14833(), WATER);
        class_2378.method_10230(field_41172, WATER_DROP.method_14833(), WATER_DROP);
    }
}
