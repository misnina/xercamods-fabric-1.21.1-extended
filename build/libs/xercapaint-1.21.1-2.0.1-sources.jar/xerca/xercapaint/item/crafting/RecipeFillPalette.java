package xerca.xercapaint.item.crafting;

import xerca.xercapaint.item.ItemPalette;
import xerca.xercapaint.item.Items;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_7225;
import net.minecraft.class_7710;
import net.minecraft.class_9694;

public class RecipeFillPalette extends class_1852 {
    public RecipeFillPalette(class_7710 category) {
        super(category);
    }

    static int getBasicColorIndex(class_1799 stack) {
        if (!(stack.method_7909() instanceof class_1769 dyeItem)) {
            return -1;
        }
        class_1767 dyeColor = dyeItem.method_7802();
        if (!class_1769.method_7803(dyeColor).equals(stack.method_7909())) {
            return -1;
        }
        int colorId = dyeColor.method_7789();
        if (colorId < 0 || colorId >= 16) {
            return -1;
        }
        return 15 - colorId;
    }

    static boolean isDye(class_1799 stack) {
        return getBasicColorIndex(stack) >= 0;
    }

    private boolean isPalette(class_1799 stack) {
        return stack.method_7909() instanceof ItemPalette;
    }

    private int findPalette(class_9694 inv) {
        for (int i = 0; i < inv.method_59983(); ++i) {
            class_1799 stack = inv.method_59984(i);
            if (isPalette(stack)) {
                return i;
            }
        }
        return -1;
    }

    private List<class_1799> findDyes(class_9694 inv, int paletteId) {
        List<class_1799> dyes = new ArrayList<>();
        for (int i = 0; i < inv.method_59983(); ++i) {
            if (i == paletteId) {
                continue;
            }
            class_1799 stack = inv.method_59984(i);
            if (isDye(stack)) {
                dyes.add(stack);
            } else if (!stack.method_7960()) {
                return new ArrayList<>();
            }
        }
        return dyes;
    }

    private byte[] loadBasicColors(class_1799 palette) {
        byte[] source = palette.method_57825(Items.PALETTE_BASIC_COLORS, new byte[0]);
        byte[] basicColors = new byte[16];
        System.arraycopy(source, 0, basicColors, 0, Math.min(source.length, basicColors.length));
        return basicColors;
    }

    /**
     * Used to check if a recipe matches current crafting inventory
     */
    @Override
    public boolean matches(class_9694 inv, class_1937 worldIn) {
        int paletteId = findPalette(inv);
        if (paletteId < 0) {
            return false;
        }
        List<class_1799> dyes = findDyes(inv, paletteId);
        return !dyes.isEmpty();
    }

    /**
     * Returns an Item that is the result of this recipe
     */
    @Override
    public class_1799 assemble(class_9694 inv, class_7225.class_7874 provider) {
        int paletteId = findPalette(inv);
        if (paletteId < 0) {
            return class_1799.field_8037;
        }
        List<class_1799> dyes = findDyes(inv, paletteId);
        if (dyes.isEmpty()) {
            return class_1799.field_8037;
        }

        class_1799 inputPalette = inv.method_59984(paletteId);
        byte[] basicColors = loadBasicColors(inputPalette);

        for (class_1799 dye : dyes) {
            int realColorId = getBasicColorIndex(dye);
            if (realColorId < 0 || basicColors[realColorId] > 0) {
                return class_1799.field_8037;
            }
            basicColors[realColorId] = 1;
        }

        // Keep all existing palette components and only update basic colors.
        class_1799 result = inputPalette.method_46651(1);
        result.method_57379(Items.PALETTE_BASIC_COLORS, basicColors);
        return result;
    }

    @Override
    public class_2371<class_1799> getRemainingItems(class_9694 inv) {
        return class_2371.method_10213(inv.method_59983(), class_1799.field_8037);
    }

    @Override
    public class_1865<?> method_8119() {
        return Items.CRAFTING_SPECIAL_PALETTE_FILLING;
    }

    /**
     * Used to determine if this recipe can fit in a grid of the given width/height
     */
    @Override
    public boolean method_8113(int width, int height) {
        return width >= 2 && height >= 2;
    }
}
