package xerca.xercapaint.item.crafting;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1799;
import net.minecraft.class_1865;
import net.minecraft.class_1869;
import net.minecraft.class_1937;
import net.minecraft.class_5455;
import net.minecraft.class_7225;
import net.minecraft.class_7710;
import net.minecraft.class_8957;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9694;
import net.minecraft.world.item.crafting.*;
import xerca.xercapaint.item.Items;

import static xerca.xercapaint.item.Items.CRAFTING_TAGLESS_SHAPED;

public class RecipeTaglessShaped extends class_1869 {
    public RecipeTaglessShaped(String group, class_7710 category, class_8957 pattern, class_1799 result, boolean showNotification) {
        super(group, category, pattern, result, showNotification);
    }

    /**
     * Used to check if a recipe matches current crafting inventory
     */
    @Override
    public boolean method_17728(class_9694 inv, class_1937 worldIn) {
        if (super.method_17728(inv, worldIn)) {
            for (int j = 0; j < inv.method_59983(); ++j) {
                class_1799 stackInSlot = inv.method_59984(j);
                if (!stackInSlot.method_7960() && stackInSlot.method_57824(Items.CANVAS_PIXELS) != null) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    /**
     * Returns an Item that is the result of this recipe
     */
    @Override
    public class_1799 method_17727(class_9694 inv, class_7225.class_7874 provider) {
        class_1799 result = super.method_17727(inv, provider);
        if (!result.method_7960()) {
            for (int j = 0; j < inv.method_59983(); ++j) {
                class_1799 stackInSlot = inv.method_59984(j);
                if (!stackInSlot.method_7960() && stackInSlot.method_57824(Items.CANVAS_PIXELS) != null) {
                    return class_1799.field_8037;
                }
            }

            return result;
        }
        return class_1799.field_8037;
    }

    public class_8957 getPattern() {
        return this.field_47320;
    }

    @Override
    public class_1865<?> method_8119() {
        return CRAFTING_TAGLESS_SHAPED;
    }

    public static class TaglessSerializer implements class_1865<RecipeTaglessShaped> {
        public static final MapCodec<RecipeTaglessShaped> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                        Codec.STRING.optionalFieldOf("group", "").forGetter(class_1869::method_8112),
                        class_7710.field_40252.fieldOf("category").orElse(class_7710.field_40251).forGetter(class_1869::method_45441),
                        class_8957.field_47321.forGetter(RecipeTaglessShaped::getPattern),
                        class_1799.field_51397.fieldOf("result").forGetter(shapedRecipe -> shapedRecipe.method_8110(class_5455.field_40585)),
                        Codec.BOOL.optionalFieldOf("show_notification", true).forGetter(class_1869::method_49188))
                .apply(instance, RecipeTaglessShaped::new));
        public static final class_9139<class_9129, RecipeTaglessShaped> STREAM_CODEC = class_9139.method_56437(RecipeTaglessShaped.TaglessSerializer::toNetwork, RecipeTaglessShaped.TaglessSerializer::fromNetwork);

        @Override
        public MapCodec<RecipeTaglessShaped> method_53736() {
            return MAP_CODEC;
        }

        @Override
        public class_9139<class_9129, RecipeTaglessShaped> method_56104() {
            return STREAM_CODEC;
        }

        private static RecipeTaglessShaped fromNetwork(class_9129 buffer) {
            String string = buffer.method_19772();
            class_7710 craftingBookCategory = buffer.method_10818(class_7710.class);
            class_8957 shapedRecipePattern = class_8957.field_48359.decode(buffer);
            class_1799 itemStack = class_1799.field_48349.decode(buffer);
            boolean bl = buffer.readBoolean();
            return new RecipeTaglessShaped(string, craftingBookCategory, shapedRecipePattern, itemStack, bl);
        }

        private static void toNetwork(class_9129 buffer, RecipeTaglessShaped recipe) {
            buffer.method_10814(recipe.method_8112());
            buffer.method_10817(recipe.method_45441());
            class_8957.field_48359.encode(buffer, recipe.getPattern());
            class_1799.field_48349.encode(buffer, recipe.method_8110(class_5455.field_40585));
            buffer.method_52964(recipe.method_49188());
        }
    }
}
