package xerca.xercapaint.item.crafting;

import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_6328;
import net.minecraft.class_7225;
import net.minecraft.class_7710;
import net.minecraft.class_9694;
import xerca.xercapaint.item.ItemCanvas;
import xerca.xercapaint.item.Items;

@class_6328
public class RecipeCanvasCloning extends class_1852 {
    public RecipeCanvasCloning(class_7710 category) {
        super(category);
    }

    /**
     * Two canvases clone together only if they share both size and material
     */
    private static boolean sameKind(ItemCanvas a, ItemCanvas b) {
        return a.getCanvasType() == b.getCanvasType() && a.isGlass() == b.isGlass();
    }

    /**
     * Used to check if a recipe matches current crafting inventory
     */
    @Override
    public boolean matches(class_9694 inv, class_1937 worldIn) {
        class_1799 orgCanvas = class_1799.field_8037;
        class_1799 freshCanvas = class_1799.field_8037;

        for (int j = 0; j < inv.method_59983(); ++j) {
            class_1799 stack = inv.method_59984(j);
            if (!stack.method_7960()) {
                if (stack.method_7909() instanceof ItemCanvas itemCanvas && stack.method_57825(Items.CANVAS_GENERATION, 0) > 0) {
                    if (!orgCanvas.method_7960()) {
                        return false;
                    }
                    if (!freshCanvas.method_7960() && !sameKind((ItemCanvas) freshCanvas.method_7909(), itemCanvas)) {
                        return false;
                    }

                    orgCanvas = stack;
                } else if (stack.method_7909() instanceof ItemCanvas itemCanvas && stack.method_57824(Items.CANVAS_GENERATION) == null) {
                    if (!freshCanvas.method_7960()) {
                        return false;
                    }
                    if (!orgCanvas.method_7960() && !sameKind((ItemCanvas) orgCanvas.method_7909(), itemCanvas)) {
                        return false;
                    }

                    freshCanvas = stack;
                }
            }
        }

        return !orgCanvas.method_7960() && !freshCanvas.method_7960();
    }

    /**
     * Returns an Item that is the result of this recipe
     */
    @Override
    public class_1799 assemble(class_9694 inv, class_7225.class_7874 provider) {
        class_1799 orgCanvas = class_1799.field_8037;
        class_1799 freshCanvas = class_1799.field_8037;

        for (int j = 0; j < inv.method_59983(); ++j) {
            class_1799 stack = inv.method_59984(j);
            if (!stack.method_7960()) {
                if (stack.method_7909() instanceof ItemCanvas itemCanvas && stack.method_57825(Items.CANVAS_GENERATION, 0) > 0) {
                    if (!orgCanvas.method_7960()) {
                        return class_1799.field_8037;
                    }
                    if (!freshCanvas.method_7960() && !sameKind((ItemCanvas) freshCanvas.method_7909(), itemCanvas)) {
                        return class_1799.field_8037;
                    }

                    orgCanvas = stack;
                } else if (stack.method_7909() instanceof ItemCanvas itemCanvas && stack.method_57824(Items.CANVAS_GENERATION) == null) {
                    if (!freshCanvas.method_7960()) {
                        return class_1799.field_8037;
                    }
                    if (!orgCanvas.method_7960() && !sameKind((ItemCanvas) orgCanvas.method_7909(), itemCanvas)) {
                        return class_1799.field_8037;
                    }

                    freshCanvas = stack;
                }
            }
        }

        int gen = orgCanvas.method_57825(Items.CANVAS_GENERATION, 0);
        if (!orgCanvas.method_7960() && !freshCanvas.method_7960() && gen > 0 && gen < 3) {
            class_1799 resultStack = new class_1799(orgCanvas.method_7909());
            resultStack.method_57379(Items.CANVAS_GENERATION, gen + 1);
            resultStack.method_57379(Items.CANVAS_PIXELS, orgCanvas.method_57824(Items.CANVAS_PIXELS));
            resultStack.method_57379(Items.CANVAS_ID, orgCanvas.method_57824(Items.CANVAS_ID));
            resultStack.method_57379(Items.CANVAS_VERSION, orgCanvas.method_57824(Items.CANVAS_VERSION));
            resultStack.method_57379(Items.CANVAS_TITLE, orgCanvas.method_57824(Items.CANVAS_TITLE));
            resultStack.method_57379(Items.CANVAS_AUTHOR, orgCanvas.method_57824(Items.CANVAS_AUTHOR));
            if (orgCanvas.method_57824(Items.CANVAS_SIDE_PIXELS) != null) {
                resultStack.method_57379(Items.CANVAS_SIDES_ACTIVE, orgCanvas.method_57825(Items.CANVAS_SIDES_ACTIVE, false));
                resultStack.method_57379(Items.CANVAS_SIDE_PIXELS, orgCanvas.method_57824(Items.CANVAS_SIDE_PIXELS));
            }
            ItemCanvas.updateStackSize(resultStack);
            return resultStack;
        } else {
            return class_1799.field_8037;
        }
    }

    @Override
    public class_2371<class_1799> getRemainingItems(class_9694 inv) {
        class_2371<class_1799> stacks = class_2371.method_10213(inv.method_59983(), class_1799.field_8037);

        for (int i = 0; i < stacks.size(); ++i) {
            class_1799 itemStack = inv.method_59984(i);
            if (itemStack.method_7909() instanceof ItemCanvas && itemStack.method_57825(Items.CANVAS_GENERATION, 0) > 0) {
                class_1799 copyStack = itemStack.method_7972();
                copyStack.method_7939(1);
                stacks.set(i, copyStack);
                break;
            }
        }

        return stacks;
    }

    @Override
    public class_1865<?> method_8119() {
        return Items.CRAFTING_SPECIAL_CANVAS_CLONING;
    }

    /**
     * Used to determine if this recipe can fit in a grid of the given width/height
     */
    @Override
    public boolean method_8113(int width, int height) {
        return width >= 2 && height >= 2;
    }
}
