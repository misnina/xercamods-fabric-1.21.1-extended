package xerca.xercapaint.item;

import xerca.xercapaint.entity.Entities;
import xerca.xercapaint.entity.EntityEasel;

import java.util.function.Consumer;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_5712;

public class ItemEasel extends class_1792 {

    public ItemEasel(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1269 method_7884(class_1838 ctx) {
        class_2350 direction = ctx.method_8038();
        if (direction == class_2350.field_11033) {
            return class_1269.field_5814;
        } else {
            class_1937 level = ctx.method_8045();
            class_1750 blockplacecontext = new class_1750(ctx);
            class_2338 blockpos = blockplacecontext.method_8037();
            class_1799 itemstack = ctx.method_8041();
            class_243 vec3 = class_243.method_24955(blockpos);
            class_238 aabb = Entities.EASEL.method_18386().method_30231(vec3.method_10216(), vec3.method_10214(), vec3.method_10215());
            if (level.method_8587(null, aabb) && level.method_8335(null, aabb).isEmpty()) {
                if (level instanceof class_3218 serverlevel) {
                    Consumer<EntityEasel> consumer = class_1299.method_48009(serverlevel, itemstack, ctx.method_8036());
                    EntityEasel easel = Entities.EASEL.method_5888(serverlevel, consumer, blockpos, class_3730.field_16465, true, true);
                    if (easel == null) {
                        return class_1269.field_5814;
                    }

                    float f = class_3532.method_15375((class_3532.method_15393(ctx.method_8044() - 180.0F) + 22.5F) / 45.0F) * 45.0F;
                    easel.method_5808(easel.method_23317(), easel.method_23318(), easel.method_23321(), f, 0.0F);
                    serverlevel.method_30771(easel);
                    level.method_43128(null, easel.method_23317(), easel.method_23318(), easel.method_23321(), class_3417.field_14969, class_3419.field_15245, 0.75F, 0.8F);
                    level.method_43275(ctx.method_8036(), class_5712.field_28738, easel.method_30950(0));
                }

                itemstack.method_7934(1);
                return class_1269.method_29236(level.field_9236);
            } else {
                return class_1269.field_5814;
            }
        }
    }
}
