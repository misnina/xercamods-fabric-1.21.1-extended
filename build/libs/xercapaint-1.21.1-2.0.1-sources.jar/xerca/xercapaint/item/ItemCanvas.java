package xerca.xercapaint.item;

import org.jetbrains.annotations.Nullable;
import org.lwjgl.system.NonnullDefault;
import xerca.xercapaint.CanvasType;
import xerca.xercapaint.client.ModClient;
import xerca.xercapaint.entity.Entities;
import xerca.xercapaint.entity.EntityCanvas;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1790;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_3544;
import net.minecraft.class_5250;
import net.minecraft.class_9334;

@NonnullDefault
public class ItemCanvas extends class_1790 {
    private static final int ORIGINAL_GENERATION = 1;
    private static final int COPY_GENERATION = 3;
    private final CanvasType canvasType;
    private final boolean glass;

    ItemCanvas(CanvasType canvasType) {
        this(canvasType, false);
    }

    ItemCanvas(CanvasType canvasType, boolean glass) {
        super(Entities.CANVAS, new class_1792.class_1793().method_7889(1));
        this.canvasType = canvasType;
        this.glass = glass;
    }

    public boolean isGlass() {
        return glass;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 worldIn, class_1657 playerIn, class_1268 hand) {
        if (worldIn.field_9236) {
            ModClient.showCanvasGui(playerIn);
        }
        return new class_1271<>(class_1269.field_5812, playerIn.method_5998(hand));
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_2338 blockpos = context.method_8037();
        class_2350 direction = context.method_8038();
        class_2338 pos = blockpos.method_10093(direction);
        class_1657 player = context.method_8036();
        class_1799 itemstack = context.method_8041();
        if (player != null) {
            if (!this.method_7834(player, direction, itemstack, pos)) {
                if (context.method_8045().field_9236) {
                    ModClient.showCanvasGui(player);
                }
            } else {
                String canvasId = itemstack.method_57824(Items.CANVAS_ID);
                List<Integer> canvasPixels = itemstack.method_57824(Items.CANVAS_PIXELS);
                if (canvasId == null || canvasPixels == null) {
                    if (context.method_8045().field_9236) {
                        ModClient.showCanvasGui(player);
                    }
                    return class_1269.field_5812;
                }

                int rotation = getRotation(direction, blockpos, player);

                if (!context.method_8045().field_9236) {
                    EntityCanvas entityCanvas = new EntityCanvas(context.method_8045(), itemstack, pos, direction, canvasType, rotation);

                    if (entityCanvas.method_6888()) {
                        entityCanvas.method_6894();
                        context.method_8045().method_8649(entityCanvas);
                        itemstack.method_7934(1);
                    }
                }
            }
        }
        return class_1269.field_5812;
    }

    private static int getRotation(class_2350 direction, class_2338 blockpos, class_1657 player) {
        int rotation = 0;
        if (direction.method_10166() == class_2350.class_2351.field_11052) {
            double xDiff = blockpos.method_10263() - player.method_23317();
            double zDiff = blockpos.method_10260() - player.method_23321();
            if (Math.abs(xDiff) > Math.abs(zDiff)) {
                if (xDiff > 0) {
                    rotation = 1;
                } else {
                    rotation = 3;
                }
            } else {
                if (zDiff > 0) {
                    rotation = 2;
                }
            }
            if (direction == class_2350.field_11033 && Math.abs(xDiff) < Math.abs(zDiff)) {
                rotation += 2;
            }
        }
        return rotation;
    }

    public static boolean hasTitle(class_1799 stack) {
        return !class_3544.method_15438(stack.method_57824(Items.CANVAS_TITLE));
    }

    public static class_2561 getFullLabel(class_1799 stack) {
        String labelString = "";
        class_2561 title = getCustomTitle(stack);
        if (title != null) {
            labelString += title.getString() + " ";
        }
        String author = stack.method_57824(Items.CANVAS_AUTHOR);

        if (!class_3544.method_15438(author)) {
            labelString += class_2561.method_43469("canvas.byAuthor", author).getString() + " ";
        }

        int generation = stack.method_57825(Items.CANVAS_GENERATION, 0);
        class_5250 label = class_2561.method_43470(labelString);
        if (generation == ORIGINAL_GENERATION) {
            label.method_27692(class_124.field_1054);
        } else if (generation >= COPY_GENERATION) {
            label.method_27692(class_124.field_1080);
        }
        return label;
    }

    @Nullable
    public static class_2561 getCustomTitle(class_1799 stack) {
        String s = stack.method_57824(Items.CANVAS_TITLE);
        if (!class_3544.method_15438(s)) {
            return class_2561.method_43470(s);
        }
        return null;
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        class_2561 comp = getCustomTitle(stack);
        if (comp != null) {
            return comp;
        }
        return super.method_7864(stack);
    }

    @Override
    @net.fabricmc.api.Environment(net.fabricmc.api.EnvType.CLIENT)
    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        List<Integer> pixels = stack.method_57824(Items.CANVAS_PIXELS);
        if (pixels != null) {
            String author = stack.method_57824(Items.CANVAS_AUTHOR);

            if (!class_3544.method_15438(author)) {
                tooltipComponents.add(class_2561.method_43469("canvas.byAuthor", author));
            }

            int generation = stack.method_57825(Items.CANVAS_GENERATION, 0);
            // generation = 0=empty, 1=original, 2=copy of org, 3=copy of copy
            if (generation > 0) {
                tooltipComponents.add(class_2561.method_43471("canvas.generation." + (generation - 1))
                        .method_27692(generation == 1 ? class_124.field_1065 : class_124.field_1080));
            }
        } else {
            tooltipComponents.add(class_2561.method_43471("canvas.empty").method_27692(class_124.field_1080));
        }
    }

    @Override
    @net.fabricmc.api.Environment(net.fabricmc.api.EnvType.CLIENT)
    public boolean method_7886(class_1799 stack) {
        return stack.method_57825(Items.CANVAS_GENERATION, 0) > 0;
    }

    public static final int SIGNED_STACK_SIZE = 16;

    /**
     * Signed canvases that are the same can be stacked
     */
    public static void updateStackSize(class_1799 stack) {
        if (stack.method_57825(Items.CANVAS_GENERATION, 0) > 0) {
            stack.method_57379(class_9334.field_50071, SIGNED_STACK_SIZE);
        } else if (stack.method_57825(class_9334.field_50071, 1) > 1) {
            stack.method_57381(class_9334.field_50071);
        }
    }

    @Override
    public void method_7860(class_1799 stack) {
        updateStackSize(stack);
    }

    // Sets the item icon height and width, which also sets the held in your hand item height and width.
    // Also sets the entity size of the canvas on the actual easle itself.
    // Does not effect it's block placement on wall.
    public int getWidth() {
        return CanvasType.getWidth(canvasType);
    }

    public int getHeight() {
        return CanvasType.getHeight(canvasType);
    }

    public CanvasType getCanvasType() {
        return canvasType;
    }

    @Override
    protected boolean method_7834(class_1657 playerIn, class_2350 directionIn, class_1799 itemStackIn, class_2338 posIn) {
        if (canvasType == CanvasType.SMALL) {
            return class_1937.method_25953(posIn) && playerIn.method_7343(posIn, directionIn, itemStackIn);
        } else {
            return !directionIn.method_10166().method_10178() && playerIn.method_7343(posIn, directionIn, itemStackIn);
        }
    }

    public static String generateName(class_1657 player) {
        return player.method_5667() + "_" + System.currentTimeMillis() / 100;
    }

    public static class_1792 canvasItemFor(CanvasType type, boolean glass) {
        return switch (type) {
            case SMALL -> glass ? Items.ITEM_CANVAS_GLASS : Items.ITEM_CANVAS;
            case LONG -> glass ? Items.ITEM_CANVAS_GLASS_LONG : Items.ITEM_CANVAS_LONG;
            case TALL -> glass ? Items.ITEM_CANVAS_GLASS_TALL : Items.ITEM_CANVAS_TALL;
            case LARGE -> glass ? Items.ITEM_CANVAS_GLASS_LARGE : Items.ITEM_CANVAS_LARGE;
            case EXTRA_LARGE -> glass ? Items.ITEM_CANVAS_GLASS_EXTRA_LARGE : Items.ITEM_CANVAS_EXTRA_LARGE;
            case EXTRA_TALL -> glass ? Items.ITEM_CANVAS_GLASS_EXTRA_TALL : Items.ITEM_CANVAS_EXTRA_TALL;
            case EXTRA_LONG -> glass ? Items.ITEM_CANVAS_GLASS_EXTRA_LONG : Items.ITEM_CANVAS_EXTRA_LONG;
            case SUPER_LARGE -> glass ? Items.ITEM_CANVAS_GLASS_SUPER_LARGE : Items.ITEM_CANVAS_SUPER_LARGE;
            case SUPER_TALL -> glass ? Items.ITEM_CANVAS_GLASS_SUPER_TALL : Items.ITEM_CANVAS_SUPER_TALL;
            case SUPER_LONG -> glass ? Items.ITEM_CANVAS_GLASS_SUPER_LONG : Items.ITEM_CANVAS_SUPER_LONG;
        };
    }
}
