package xerca.xercapaint.item;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1865;
import net.minecraft.class_1866;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_5699;
import net.minecraft.class_7923;
import net.minecraft.class_9135;
import net.minecraft.class_9331;
import xerca.xercapaint.CanvasType;
import xerca.xercapaint.Mod;
import xerca.xercapaint.item.crafting.RecipeCanvasCloning;
import xerca.xercapaint.item.crafting.RecipeFillPalette;
import xerca.xercapaint.item.crafting.RecipeTaglessShaped;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.List;

public final class Items {
    private Items() {
    }

    public static final ItemPalette ITEM_PALETTE = new ItemPalette();
    public static final ItemCanvas ITEM_CANVAS = new ItemCanvas(CanvasType.SMALL);
    public static final ItemCanvas ITEM_CANVAS_LARGE = new ItemCanvas(CanvasType.LARGE);
    public static final ItemCanvas ITEM_CANVAS_LONG = new ItemCanvas(CanvasType.LONG);
    public static final ItemCanvas ITEM_CANVAS_TALL = new ItemCanvas(CanvasType.TALL);
    public static final ItemCanvas ITEM_CANVAS_EXTRA_LARGE = new ItemCanvas(CanvasType.EXTRA_LARGE);
    public static final ItemCanvas ITEM_CANVAS_EXTRA_LONG = new ItemCanvas(CanvasType.EXTRA_LONG);
    public static final ItemCanvas ITEM_CANVAS_EXTRA_TALL = new ItemCanvas(CanvasType.EXTRA_TALL);
    public static final ItemCanvas ITEM_CANVAS_SUPER_LARGE = new ItemCanvas(CanvasType.SUPER_LARGE);
    public static final ItemCanvas ITEM_CANVAS_SUPER_LONG = new ItemCanvas(CanvasType.SUPER_LONG);
    public static final ItemCanvas ITEM_CANVAS_SUPER_TALL = new ItemCanvas(CanvasType.SUPER_TALL);
    public static final ItemCanvas ITEM_CANVAS_GLASS = new ItemCanvas(CanvasType.SMALL, true);
    public static final ItemCanvas ITEM_CANVAS_GLASS_LARGE = new ItemCanvas(CanvasType.LARGE, true);
    public static final ItemCanvas ITEM_CANVAS_GLASS_LONG = new ItemCanvas(CanvasType.LONG, true);
    public static final ItemCanvas ITEM_CANVAS_GLASS_TALL = new ItemCanvas(CanvasType.TALL, true);
    public static final ItemCanvas ITEM_CANVAS_GLASS_EXTRA_LARGE = new ItemCanvas(CanvasType.EXTRA_LARGE, true);
    public static final ItemCanvas ITEM_CANVAS_GLASS_EXTRA_LONG = new ItemCanvas(CanvasType.EXTRA_LONG, true);
    public static final ItemCanvas ITEM_CANVAS_GLASS_EXTRA_TALL = new ItemCanvas(CanvasType.EXTRA_TALL, true);
    public static final ItemCanvas ITEM_CANVAS_GLASS_SUPER_LARGE = new ItemCanvas(CanvasType.SUPER_LARGE, true);
    public static final ItemCanvas ITEM_CANVAS_GLASS_SUPER_LONG = new ItemCanvas(CanvasType.SUPER_LONG, true);
    public static final ItemCanvas ITEM_CANVAS_GLASS_SUPER_TALL = new ItemCanvas(CanvasType.SUPER_TALL, true);
    public static final ItemEasel ITEM_EASEL = new ItemEasel(new class_1792.class_1793().method_7889(1));

    public static final class_1865<RecipeFillPalette> CRAFTING_SPECIAL_PALETTE_FILLING = new class_1866<>(RecipeFillPalette::new);
    public static final class_1865<RecipeCanvasCloning> CRAFTING_SPECIAL_CANVAS_CLONING = new class_1866<>(RecipeCanvasCloning::new);
    public static final class_1865<RecipeTaglessShaped> CRAFTING_TAGLESS_SHAPED = new RecipeTaglessShaped.TaglessSerializer();
    public static final class_9331<List<Integer>> CANVAS_PIXELS = class_9331.<List<Integer>>method_57873().method_57881(Codec.list(Codec.INT)).method_57882(class_9135.method_56368(Codec.list(Codec.INT))).method_57880();
    public static final class_9331<Boolean> CANVAS_SIDES_ACTIVE = class_9331.<Boolean>method_57873().method_57881(Codec.BOOL).method_57882(class_9135.field_48547).method_57880();
    public static final class_9331<List<Integer>> CANVAS_SIDE_PIXELS = class_9331.<List<Integer>>method_57873().method_57881(Codec.list(Codec.INT)).method_57882(class_9135.method_56368(Codec.list(Codec.INT))).method_57880();
    public static final class_9331<Integer> CANVAS_VERSION = class_9331.<Integer>method_57873().method_57881(class_5699.field_33441).method_57882(class_9135.field_48550).method_57880();
    public static final class_9331<String> CANVAS_ID = class_9331.<String>method_57873().method_57881(class_5699.field_41759).method_57882(class_9135.field_48554).method_57880();
    public static final class_9331<String> CANVAS_TITLE = class_9331.<String>method_57873().method_57881(Codec.STRING).method_57880();
    public static final class_9331<String> CANVAS_AUTHOR = class_9331.<String>method_57873().method_57881(Codec.STRING).method_57880();
    public static final class_9331<Integer> CANVAS_GENERATION = class_9331.<Integer>method_57873().method_57881(class_5699.field_33441).method_57880();
    public static final class_9331<byte[]> PALETTE_BASIC_COLORS = class_9331.<byte[]>method_57873().method_57881(Codec.BYTE_BUFFER.flatXmap(byteBuffer -> DataResult.success(byteBuffer.array()), bytes -> DataResult.success(ByteBuffer.wrap(bytes)))).method_57882(class_9135.field_48987).method_57880();
    public static final class_9331<ItemPalette.ComponentCustomColor> PALETTE_CUSTOM_COLORS = class_9331.<ItemPalette.ComponentCustomColor>method_57873().method_57881(ItemPalette.ComponentCustomColor.CODEC).method_57880();

    public static final class_1761 PAINT_TAB = FabricItemGroup.builder()
            .method_47320(() -> new class_1799(ITEM_PALETTE))
            .method_47317((params, output) -> {
                class_1799 fullPalette = new class_1799(ITEM_PALETTE);
                byte[] basicColors = new byte[16];
                Arrays.fill(basicColors, (byte) 1);
                fullPalette.method_57379(PALETTE_BASIC_COLORS, basicColors);

                output.method_45421(ITEM_PALETTE);
                output.method_45420(fullPalette);
                output.method_45421(ITEM_CANVAS);
                output.method_45421(ITEM_CANVAS_LONG);
                output.method_45421(ITEM_CANVAS_TALL);
                output.method_45421(ITEM_CANVAS_LARGE);
                output.method_45421(ITEM_CANVAS_EXTRA_LONG);
                output.method_45421(ITEM_CANVAS_EXTRA_TALL);
                output.method_45421(ITEM_CANVAS_EXTRA_LARGE);
                output.method_45421(ITEM_CANVAS_SUPER_LONG);
                output.method_45421(ITEM_CANVAS_SUPER_TALL);
                output.method_45421(ITEM_CANVAS_SUPER_LARGE);
                output.method_45421(ITEM_CANVAS_GLASS);
                output.method_45421(ITEM_CANVAS_GLASS_LONG);
                output.method_45421(ITEM_CANVAS_GLASS_TALL);
                output.method_45421(ITEM_CANVAS_GLASS_LARGE);
                output.method_45421(ITEM_CANVAS_GLASS_EXTRA_LONG);
                output.method_45421(ITEM_CANVAS_GLASS_EXTRA_TALL);
                output.method_45421(ITEM_CANVAS_GLASS_EXTRA_LARGE);
                output.method_45421(ITEM_CANVAS_GLASS_SUPER_LONG);
                output.method_45421(ITEM_CANVAS_GLASS_SUPER_TALL);
                output.method_45421(ITEM_CANVAS_GLASS_SUPER_LARGE);
                output.method_45421(ITEM_EASEL);
            })
            .method_47321(class_2561.method_43471("itemGroup.xercapaint.paint_tab"))
            .method_47324();

    public static void registerRecipes() {
        registerRecipeSerializer("crafting_special_palette_filling", CRAFTING_SPECIAL_PALETTE_FILLING);
        registerRecipeSerializer("crafting_special_canvas_cloning", CRAFTING_SPECIAL_CANVAS_CLONING);
        registerRecipeSerializer("crafting_tagless_shaped", CRAFTING_TAGLESS_SHAPED);
    }

    public static void registerItems() {
        registerItem("item_palette", ITEM_PALETTE);
        registerItem("item_canvas", ITEM_CANVAS);
        registerItem("item_canvas_large", ITEM_CANVAS_LARGE);
        registerItem("item_canvas_long", ITEM_CANVAS_LONG);
        registerItem("item_canvas_tall", ITEM_CANVAS_TALL);
        registerItem("item_canvas_extra_large", ITEM_CANVAS_EXTRA_LARGE);
        registerItem("item_canvas_extra_long", ITEM_CANVAS_EXTRA_LONG);
        registerItem("item_canvas_extra_tall", ITEM_CANVAS_EXTRA_TALL);
        registerItem("item_canvas_super_large", ITEM_CANVAS_SUPER_LARGE);
        registerItem("item_canvas_super_long", ITEM_CANVAS_SUPER_LONG);
        registerItem("item_canvas_super_tall", ITEM_CANVAS_SUPER_TALL);
        registerItem("item_canvas_glass", ITEM_CANVAS_GLASS);
        registerItem("item_canvas_glass_large", ITEM_CANVAS_GLASS_LARGE);
        registerItem("item_canvas_glass_long", ITEM_CANVAS_GLASS_LONG);
        registerItem("item_canvas_glass_tall", ITEM_CANVAS_GLASS_TALL);
        registerItem("item_canvas_glass_extra_large", ITEM_CANVAS_GLASS_EXTRA_LARGE);
        registerItem("item_canvas_glass_extra_long", ITEM_CANVAS_GLASS_EXTRA_LONG);
        registerItem("item_canvas_glass_extra_tall", ITEM_CANVAS_GLASS_EXTRA_TALL);
        registerItem("item_canvas_glass_super_large", ITEM_CANVAS_GLASS_SUPER_LARGE);
        registerItem("item_canvas_glass_super_long", ITEM_CANVAS_GLASS_SUPER_LONG);
        registerItem("item_canvas_glass_super_tall", ITEM_CANVAS_GLASS_SUPER_TALL);
        registerItem("item_easel", ITEM_EASEL);

        class_2378.method_10230(class_7923.field_44687, Mod.id("paint_tab"), PAINT_TAB);
    }

    public static void registerDataComponents() {
        registerComponentType("canvas_generation", CANVAS_GENERATION);
        registerComponentType("canvas_version", CANVAS_VERSION);
        registerComponentType("canvas_id", CANVAS_ID);
        registerComponentType("canvas_title", CANVAS_TITLE);
        registerComponentType("canvas_author", CANVAS_AUTHOR);
        registerComponentType("canvas_pixels", CANVAS_PIXELS);
        registerComponentType("canvas_sides_active", CANVAS_SIDES_ACTIVE);
        registerComponentType("canvas_side_pixels", CANVAS_SIDE_PIXELS);
        registerComponentType("palette_basic_colors", PALETTE_BASIC_COLORS);
        registerComponentType("palette_custom_colors", PALETTE_CUSTOM_COLORS);
    }

    private static void registerComponentType(String name, class_9331<?> type) {
        class_2378.method_10230(class_7923.field_49658, Mod.id(name), type);
    }

    private static void registerItem(String name, class_1792 item) {
        class_2378.method_10230(class_7923.field_41178, Mod.id(name), item);
    }

    private static void registerRecipeSerializer(String name, class_1865<?> recipeSerializer) {
        class_2378.method_10230(class_7923.field_41189, Mod.id(name), recipeSerializer);
    }
}
