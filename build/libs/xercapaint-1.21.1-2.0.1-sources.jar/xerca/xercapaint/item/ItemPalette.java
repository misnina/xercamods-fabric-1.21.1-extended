package xerca.xercapaint.item;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.codecs.PrimitiveCodec;
import xerca.xercapaint.PaletteUtil;
import xerca.xercapaint.client.ModClient;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class ItemPalette extends class_1792 {
    private static final int BASIC_COLOR_COUNT = 16;

    ItemPalette() {
        super(new class_1793().method_7889(1));
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 worldIn, class_1657 playerIn, class_1268 hand) {
        if (worldIn.field_9236) {
            ModClient.showCanvasGui(playerIn);
        }
        return new class_1271<>(class_1269.field_5812, playerIn.method_5998(hand));
    }

    public static boolean isFull(class_1799 stack) {
        return basicColorCount(stack) == BASIC_COLOR_COUNT;
    }

    public static int basicColorCount(class_1799 stack) {
        if (stack.method_7909() != Items.ITEM_PALETTE) {
            return 0;
        }
        byte[] basicColors = stack.method_57824(Items.PALETTE_BASIC_COLORS);
        if (basicColors != null && basicColors.length == BASIC_COLOR_COUNT) {
            int basicCount = 0;
            for (byte basicColor : basicColors) {
                basicCount += basicColor;
            }
            return basicCount;
        }
        return 0;
    }

    @Override
    @net.fabricmc.api.Environment(net.fabricmc.api.EnvType.CLIENT)
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 flagIn) {
        byte[] basicColors = stack.method_57824(Items.PALETTE_BASIC_COLORS);
        ComponentCustomColor customColorComp = stack.method_57824(Items.PALETTE_CUSTOM_COLORS);
        if (basicColors == null && customColorComp == null) {
            tooltip.add(class_2561.method_43471("palette.empty").method_27692(class_124.field_1080));
        } else {
            if (basicColors != null && basicColors.length == BASIC_COLOR_COUNT) {
                int basicCount = 0;
                for (byte basicColor : basicColors) {
                    basicCount += basicColor;
                }
                tooltip.add(class_2561.method_43469("palette.basic_count", String.valueOf(basicCount)).method_27692(class_124.field_1080));
            }

            if (customColorComp != null) {
                int fullCount = 0;
                for (PaletteUtil.CustomColor color : customColorComp.colors) {
                    if (color.numberOfColors > 0) {
                        fullCount++;
                    }
                }
                tooltip.add(class_2561.method_43469("palette.custom_count", String.valueOf(fullCount)).method_27692(class_124.field_1080));
            }
        }
    }

    public static final class ComponentCustomColor {
        public static final int CUSTOM_COLOR_COUNT = 12;
        public PaletteUtil.CustomColor[] colors;

        public ComponentCustomColor(PaletteUtil.CustomColor[] customColors) {
            if (customColors.length != CUSTOM_COLOR_COUNT) {
                throw new IllegalArgumentException("customColors must have exactly " + CUSTOM_COLOR_COUNT + " elements.");
            }

            colors = customColors;
        }

        public static final PrimitiveCodec<ComponentCustomColor> CODEC = new PrimitiveCodec<>() {
            @Override
            public <T> DataResult<ComponentCustomColor> read(final DynamicOps<T> ops, final T input) {
                return ops.getIntStream(input).flatMap(intStream -> {
                    int[] allColorsArray = intStream.toArray();

                    if (allColorsArray.length != CUSTOM_COLOR_COUNT * 5) {
                        return DataResult.error(() -> "Expected " + CUSTOM_COLOR_COUNT * 5 + " integer values, but got: " + allColorsArray.length);
                    }

                    PaletteUtil.CustomColor[] customColors = new PaletteUtil.CustomColor[CUSTOM_COLOR_COUNT];

                    for (int i = 0; i < CUSTOM_COLOR_COUNT; i++) {
                        int baseIndex = i * 5;
                        int totalRed = allColorsArray[baseIndex];
                        int totalGreen = allColorsArray[baseIndex + 1];
                        int totalBlue = allColorsArray[baseIndex + 2];
                        int totalMaximum = allColorsArray[baseIndex + 3];
                        int numberOfColors = allColorsArray[baseIndex + 4];

                        customColors[i] = new PaletteUtil.CustomColor(totalRed, totalGreen, totalBlue, totalMaximum, numberOfColors);
                    }

                    return DataResult.success(new ComponentCustomColor(customColors));
                });
            }


            @Override
            public <T> T write(final DynamicOps<T> ops, final ComponentCustomColor value) {
                IntStream intStream = Arrays.stream(value.colors)
                        .flatMapToInt(cc -> Arrays.stream(new int[]{cc.totalRed, cc.totalGreen, cc.totalBlue, cc.totalMaximum, cc.numberOfColors}));
                return ops.createIntList(intStream);
            }

            @Override
            public String toString() {
                return "CustomColorCodec";
            }
        };
    }

}
