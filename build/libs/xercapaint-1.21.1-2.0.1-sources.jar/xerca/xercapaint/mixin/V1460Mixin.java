package xerca.xercapaint.mixin;

import com.mojang.datafixers.DSL;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.templates.TypeTemplate;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1208;
import net.minecraft.class_1238;

@SuppressWarnings({"UnusedMethod", "UnusedVariable", "unused"})
@Mixin(class_1238.class)
public abstract class V1460Mixin {
    // Called reflectively by Mixin injection.
    @Inject(method = "registerEntities", at = @At("TAIL"), cancellable = true, locals = LocalCapture.CAPTURE_FAILSOFT)
    private void registerEntitiesMixin(Schema schema, CallbackInfoReturnable<Map<String, Supplier<TypeTemplate>>> cir, Map<String, Supplier<TypeTemplate>> map) {
        schema.register(map, "xercapaint:easel", string -> DSL.optionalFields("Item", class_1208.field_5712.in(schema)));
        schema.register(map, "xercapaint:canvas", string -> DSL.optionalFields("_", class_1208.field_5712.in(schema)));
    }
}
