package xerca.xercapaint.packets;

import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import xerca.xercapaint.Mod;

public record EaselLeftPacket(int easelId) implements class_8710 {
    public static final class_8710.class_9154<EaselLeftPacket> PACKET_ID = new class_8710.class_9154<>(Mod.id("easel_left"));
    public static final class_9139<class_2540, EaselLeftPacket> PACKET_CODEC = class_9139.method_56438(EaselLeftPacket::encode, EaselLeftPacket::decode);

    public void encode(class_2540 buf) {
        buf.method_53002(easelId);
    }

    public static EaselLeftPacket decode(class_2540 buf) {
        int easelId = buf.readInt();
        return new EaselLeftPacket(easelId);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }
}

