package xerca.xercapaint.packets;

import xerca.xercapaint.Mod;

import java.util.Objects;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record ImportPaintingSendPacket(class_2487 tag) implements class_8710 {
    public static final class_8710.class_9154<ImportPaintingSendPacket> PACKET_ID = new class_8710.class_9154<>(Mod.id("import_painting_send"));
    public static final class_9139<class_2540, ImportPaintingSendPacket> PACKET_CODEC = class_9139.method_56438(ImportPaintingSendPacket::encode, ImportPaintingSendPacket::decode);

    public void encode(class_2540 buf) {
        buf.method_10794(tag);
    }

    public static ImportPaintingSendPacket decode(class_2540 buf) {
        class_2487 tag = buf.method_10798();
        if (tag == null) {
            throw new IllegalArgumentException("Missing painting tag in ImportPaintingSendPacket");
        }
        return new ImportPaintingSendPacket(tag);
    }

    public ImportPaintingSendPacket {
        tag = Objects.requireNonNull(tag, "Painting tag").method_10553();
    }

    @Override
    public class_2487 tag() {
        return tag.method_10553();
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }
}
