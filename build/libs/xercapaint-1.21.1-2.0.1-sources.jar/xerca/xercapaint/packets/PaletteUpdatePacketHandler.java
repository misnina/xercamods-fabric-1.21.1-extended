package xerca.xercapaint.packets;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import xerca.xercapaint.item.ItemPalette;
import xerca.xercapaint.item.Items;

public class PaletteUpdatePacketHandler implements ServerPlayNetworking.PlayPayloadHandler<PaletteUpdatePacket> {

    private static void processMessage(PaletteUpdatePacket msg, class_3222 pl) {
        class_1799 palette = pl.method_6047();

        if (palette.method_7960() || palette.method_7909() != Items.ITEM_PALETTE) {
            palette = pl.method_6079();
            if (palette.method_7960() || palette.method_7909() != Items.ITEM_PALETTE) {
                return;
            }
        }

        palette.method_57379(Items.PALETTE_CUSTOM_COLORS, new ItemPalette.ComponentCustomColor(msg.paletteColors()));
    }

    @Override
    public void receive(PaletteUpdatePacket packet, ServerPlayNetworking.Context context) {
        context.server().execute(() -> processMessage(packet, context.player()));
    }
}
