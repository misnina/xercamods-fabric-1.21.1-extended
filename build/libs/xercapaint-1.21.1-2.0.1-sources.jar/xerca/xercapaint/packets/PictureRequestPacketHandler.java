package xerca.xercapaint.packets;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_3222;
import xerca.xercapaint.entity.EntityCanvas;

public class PictureRequestPacketHandler implements ServerPlayNetworking.PlayPayloadHandler<PictureRequestPacket> {
    private static void processMessage(PictureRequestPacket msg, class_3222 pl) {
        String canvasId = msg.canvasId();
        EntityCanvas.Picture picture = EntityCanvas.PICTURES.get(canvasId);
        if (picture != null) {
            PictureSendPacket pack = new PictureSendPacket(canvasId, picture.version(), picture.pixels(), picture.sidesActive(), picture.sidePixels());
            ServerPlayNetworking.send(pl, pack);
        }
    }

    @Override
    public void receive(PictureRequestPacket packet, ServerPlayNetworking.Context context) {
        context.server().execute(() -> processMessage(packet, context.player()));
    }
}
