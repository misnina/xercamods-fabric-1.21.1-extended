package xerca.xercapaint.packets;

import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import xerca.xercapaint.Mod;
import xerca.xercapaint.PaletteUtil;

public record PaletteUpdatePacket(PaletteUtil.CustomColor[] paletteColors) implements class_8710 {
    public static final class_8710.class_9154<PaletteUpdatePacket> PACKET_ID = new class_8710.class_9154<>(Mod.id("palette_update"));
    public static final class_9139<class_2540, PaletteUpdatePacket> PACKET_CODEC = class_9139.method_56438(PaletteUpdatePacket::encode, PaletteUpdatePacket::decode);

    public void encode(class_2540 buf) {
        for (PaletteUtil.CustomColor color : paletteColors) {
            color.writeToBuffer(buf);
        }
    }

    public static PaletteUpdatePacket decode(class_2540 buf) {
        PaletteUtil.CustomColor[] paletteColors = new PaletteUtil.CustomColor[12];
        for (int i = 0; i < paletteColors.length; i++) {
            paletteColors[i] = new PaletteUtil.CustomColor(buf);
        }
        return new PaletteUpdatePacket(paletteColors);
    }

    public PaletteUpdatePacket {
        paletteColors = paletteColors.clone();
    }

    @Override
    public PaletteUtil.CustomColor[] paletteColors() {
        return paletteColors.clone();
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }
}

