package xerca.xercapaint.packets;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import xerca.xercapaint.CommandExport;

public class ExportPaintingPacketHandler implements ClientPlayNetworking.PlayPayloadHandler<ExportPaintingPacket> {
    private static void processMessage(ExportPaintingPacket msg) {
        class_310 m = class_310.method_1551();
        if (m.field_1724 != null) {
            if (CommandExport.doExport(m.field_1724, msg.canvasId())) {
                m.field_1724.method_43496(class_2561.method_43469("xercapaint.export.success", msg.canvasId()).method_27692(class_124.field_1060));
            } else {
                m.field_1724.method_43496(class_2561.method_43469("xercapaint.export.fail", msg.canvasId()).method_27692(class_124.field_1061));
            }
        }
    }

    @Override
    public void receive(ExportPaintingPacket packet, ClientPlayNetworking.Context context) {
        context.client().execute(() -> processMessage(packet));
    }
}
