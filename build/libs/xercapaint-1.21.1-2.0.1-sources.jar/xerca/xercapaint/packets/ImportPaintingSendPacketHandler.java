package xerca.xercapaint.packets;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2487;
import net.minecraft.class_3222;
import xerca.xercapaint.CommandImport;

public class ImportPaintingSendPacketHandler implements ServerPlayNetworking.PlayPayloadHandler<ImportPaintingSendPacket> {

    private static void processMessage(ImportPaintingSendPacket msg, class_3222 sender) {
        class_2487 tag = msg.tag();
        CommandImport.doImport(tag, sender);
    }

    @Override
    public void receive(ImportPaintingSendPacket packet, ServerPlayNetworking.Context context) {
        context.server().execute(() -> processMessage(packet, context.player()));
    }
}
