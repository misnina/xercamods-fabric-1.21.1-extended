package xerca.xercapaint.packets;

import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import xerca.xercapaint.Mod;

public record CloseGuiPacket() implements class_8710 {
    public static final class_8710.class_9154<CloseGuiPacket> PACKET_ID = new class_8710.class_9154<>(Mod.id("close_gui"));
    public static final class_9139<class_2540, CloseGuiPacket> PACKET_CODEC = class_9139.method_56438(CloseGuiPacket::encode, CloseGuiPacket::decode);

    @SuppressWarnings("EmptyMethod")
    public void encode(class_2540 ignoredBuf) {
        // No data
    }

    public static CloseGuiPacket decode(class_2540 ignoredBuf) {
        return new CloseGuiPacket();
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }
}

