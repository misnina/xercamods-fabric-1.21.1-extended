package xerca.xercapaint.packets;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_310;

public class CloseGuiPacketHandler implements ClientPlayNetworking.PlayPayloadHandler<CloseGuiPacket> {
    private static void processMessage() {
        class_310.method_1551().method_1507(null);
    }

    @Override
    public void receive(CloseGuiPacket payload, ClientPlayNetworking.Context context) {
        context.client().execute(CloseGuiPacketHandler::processMessage);
    }
}
