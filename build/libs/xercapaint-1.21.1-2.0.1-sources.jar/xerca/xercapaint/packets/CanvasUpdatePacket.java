package xerca.xercapaint.packets;

import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import xerca.xercapaint.CanvasType;
import xerca.xercapaint.Mod;
import xerca.xercapaint.PaletteUtil;

public record CanvasUpdatePacket(int[] pixels, boolean signed, String title, String canvasId, int version, int easelId,
                                 PaletteUtil.CustomColor[] paletteColors,
                                 CanvasType canvasType, boolean sidesActive,
                                 int[] sidePixels) implements class_8710 {
    public static final class_8710.class_9154<CanvasUpdatePacket> PACKET_ID = new class_8710.class_9154<>(Mod.id("canvas_update"));
    public static final class_9139<class_2540, CanvasUpdatePacket> PACKET_CODEC = class_9139.method_56438(CanvasUpdatePacket::encode, CanvasUpdatePacket::decode);

    public void encode(class_2540 buf) {
        for (PaletteUtil.CustomColor color : paletteColors) {
            color.writeToBuffer(buf);
        }
        buf.method_53002(easelId);
        buf.method_52997(canvasType.toByte());
        buf.method_53002(version);
        buf.method_10814(canvasId);
        buf.method_10814(title);
        buf.method_52964(signed);
        buf.method_10806(pixels);
        buf.method_52964(sidesActive);
        buf.method_10806(sidePixels);
    }

    public static CanvasUpdatePacket decode(class_2540 buf) {
        PaletteUtil.CustomColor[] paletteColors = new PaletteUtil.CustomColor[12];
        for (int i = 0; i < paletteColors.length; i++) {
            paletteColors[i] = new PaletteUtil.CustomColor(buf);
        }
        int easelId = buf.readInt();
        CanvasType canvasType = CanvasType.fromByte(buf.readByte());
        int version = buf.readInt();
        String canvasId = buf.method_10800(64);
        String title = buf.method_10800(32);
        boolean signed = buf.readBoolean();
        int area = CanvasType.getHeight(canvasType) * CanvasType.getWidth(canvasType);
        int[] pixels = buf.method_10799(area);
        boolean sidesActive = buf.readBoolean();
        int[] sidePixels = buf.method_10799(xerca.xercapaint.CanvasSides.count(canvasType));
        return new CanvasUpdatePacket(pixels, signed, title, canvasId, version, easelId, paletteColors, canvasType, sidesActive, sidePixels);
    }

    public CanvasUpdatePacket {
        pixels = pixels.clone();
        paletteColors = paletteColors.clone();
        sidePixels = sidePixels.clone();
    }

    @Override
    public int[] pixels() {
        return pixels.clone();
    }

    @Override
    public PaletteUtil.CustomColor[] paletteColors() {
        return paletteColors.clone();
    }

    @Override
    public int[] sidePixels() {
        return sidePixels.clone();
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }
}
