package xerca.xercapaint.packets;

import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import xerca.xercapaint.Mod;

public record PictureRequestPacket(String canvasId) implements class_8710 {
    public static final class_8710.class_9154<PictureRequestPacket> PACKET_ID = new class_8710.class_9154<>(Mod.id("picture_request"));
    public static final class_9139<class_2540, PictureRequestPacket> PACKET_CODEC = class_9139.method_56438(PictureRequestPacket::encode, PictureRequestPacket::decode);

    public void encode(class_2540 buf) {
        buf.method_10814(canvasId);
    }

    public static PictureRequestPacket decode(class_2540 buf) {
        String canvasId = buf.method_10800(64);
        return new PictureRequestPacket(canvasId);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }
}

