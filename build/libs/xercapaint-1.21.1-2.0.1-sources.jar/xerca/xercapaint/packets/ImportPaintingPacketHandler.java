package xerca.xercapaint.packets;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_2487;
import net.minecraft.class_2507;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_746;
import xerca.xercapaint.Mod;

import java.io.IOException;
import java.nio.file.Path;

public class ImportPaintingPacketHandler implements ClientPlayNetworking.PlayPayloadHandler<ImportPaintingPacket> {

    private static void processMessage(ImportPaintingPacket msg) {
        String filename = msg.canvasId() + ".paint";
        String filepath = "paintings/" + filename;
        try {
            class_2487 tag = class_2507.method_10633(Path.of(filepath));
            if (tag == null) {
                throw new IOException("Painting file did not contain NBT data");
            }
            ClientPlayNetworking.send(new ImportPaintingSendPacket(tag));
        } catch (IOException e) {
            Mod.LOGGER.error("Could not read painting file {}", filepath, e);
            class_310 minecraft = class_310.method_1551();
            class_746 player = minecraft.field_1724;
            if (player != null) {
                player.method_43496(class_2561.method_43469("xercapaint.import.fail.4", filepath).method_27692(class_124.field_1061));
            }
        }
    }

    @Override
    public void receive(ImportPaintingPacket packet, ClientPlayNetworking.Context context) {
        context.client().execute(() -> processMessage(packet));
    }
}
