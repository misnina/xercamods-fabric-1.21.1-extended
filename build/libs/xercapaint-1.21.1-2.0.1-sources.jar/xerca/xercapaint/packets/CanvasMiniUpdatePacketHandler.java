package xerca.xercapaint.packets;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import xerca.xercapaint.Mod;
import xerca.xercapaint.entity.EntityEasel;
import xerca.xercapaint.item.ItemCanvas;
import xerca.xercapaint.item.ItemPalette;
import xerca.xercapaint.item.Items;

import java.util.Arrays;

public class CanvasMiniUpdatePacketHandler implements ServerPlayNetworking.PlayPayloadHandler<CanvasMiniUpdatePacket> {
    public static void processMessage(CanvasMiniUpdatePacket msg, class_3222 pl) {
        class_1799 canvas;
        class_1799 palette;
        EntityEasel easel = null;

        if (msg.easelId() > -1) {
            class_1297 entity = pl.method_37908().method_8469(msg.easelId());
            if (entity == null) {
                Mod.LOGGER.error("CanvasMiniUpdatePacket: Easel entity not found! easelId: {}", msg.easelId());
                return;
            }
            if (!(entity instanceof EntityEasel entityEasel)) {
                Mod.LOGGER.error("CanvasMiniUpdatePacket: Entity found is not an easel! easelId: {}", msg.easelId());
                return;
            }
            if (entityEasel.getPainter() == null || !entityEasel.getPainter().method_5667().equals(pl.method_5667())) {
                Mod.LOGGER.warn("CanvasMiniUpdatePacket: Unauthorized paint update. easelId: {} player: {}", msg.easelId(), pl.method_5477().getString());
                return;
            }
            if (pl.method_5858(entityEasel) > 64.0D) {
                Mod.LOGGER.warn("CanvasMiniUpdatePacket: Player too far from easel. easelId: {} player: {}", msg.easelId(), pl.method_5477().getString());
                return;
            }
            easel = entityEasel;
            canvas = easel.getItem();
            if (!(canvas.method_7909() instanceof ItemCanvas)) {
                Mod.LOGGER.error("CanvasMiniUpdatePacket: Canvas not found inside easel!");
                return;
            }
        } else {
            canvas = pl.method_6047();
            palette = pl.method_6079();
            if (canvas.method_7909() instanceof ItemPalette) {
                canvas = palette;
            }
        }

        if (!canvas.method_7960() && canvas.method_7909() instanceof ItemCanvas) {
            canvas.method_57379(Items.CANVAS_PIXELS, Arrays.stream(msg.pixels()).boxed().toList());
            canvas.method_57379(Items.CANVAS_ID, msg.canvasId());
            canvas.method_57379(Items.CANVAS_VERSION, msg.version());
            canvas.method_57379(Items.CANVAS_GENERATION, 0);
            canvas.method_57379(Items.CANVAS_SIDES_ACTIVE, msg.sidesActive());
            if (msg.sidePixels().length > 0) {
                canvas.method_57379(Items.CANVAS_SIDE_PIXELS, Arrays.stream(msg.sidePixels()).boxed().toList());
            }

            if (easel != null) {
                easel.setItem(canvas, false);
            }

            Mod.LOGGER.debug("Handling canvas update: Name: {} V: {}", msg.canvasId(), msg.version());
        }
    }

    @Override
    public void receive(CanvasMiniUpdatePacket packet, ServerPlayNetworking.Context context) {
        context.server().execute(() -> processMessage(packet, context.player()));
    }
}
