package xerca.xercapaint.packets;

import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import xerca.xercapaint.CanvasType;
import xerca.xercapaint.Mod;

public record CanvasMiniUpdatePacket(int[] pixels, String canvasId, int version, int easelId,
                                     CanvasType canvasType, boolean sidesActive,
                                     int[] sidePixels) implements class_8710 {
    public static final class_8710.class_9154<CanvasMiniUpdatePacket> PACKET_ID = new class_8710.class_9154<>(Mod.id("canvas_mini_update"));
    public static final class_9139<class_2540, CanvasMiniUpdatePacket> PACKET_CODEC = class_9139.method_56438(CanvasMiniUpdatePacket::encode, CanvasMiniUpdatePacket::decode);

    public void encode(class_2540 buf) {
        buf.method_53002(easelId);
        buf.method_52997(canvasType.toByte());
        buf.method_53002(version);
        buf.method_10814(canvasId);
        buf.method_10806(pixels);
        buf.method_52964(sidesActive);
        buf.method_10806(sidePixels);
    }

    public static CanvasMiniUpdatePacket decode(class_2540 buf) {
        int easelId = buf.readInt();
        CanvasType canvasType = CanvasType.fromByte(buf.readByte());
        int version = buf.readInt();
        String canvasId = buf.method_10800(64);
        int area = CanvasType.getHeight(canvasType) * CanvasType.getWidth(canvasType);
        int[] pixels = buf.method_10799(area);
        boolean sidesActive = buf.readBoolean();
        int[] sidePixels = buf.method_10799(xerca.xercapaint.CanvasSides.count(canvasType));
        return new CanvasMiniUpdatePacket(pixels, canvasId, version, easelId, canvasType, sidesActive, sidePixels);
    }

    public CanvasMiniUpdatePacket {
        pixels = pixels.clone();
        sidePixels = sidePixels.clone();
    }

    @Override
    public int[] pixels() {
        return pixels.clone();
    }

    @Override
    public int[] sidePixels() {
        return sidePixels.clone();
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }
}
