package xerca.xercapaint.packets;

import net.minecraft.class_1268;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import xerca.xercapaint.Mod;

public record OpenGuiPacket(int easelId, boolean allowed, boolean edit,
                            class_1268 hand) implements class_8710 {
    public static final class_8710.class_9154<OpenGuiPacket> PACKET_ID = new class_8710.class_9154<>(Mod.id("open_gui"));
    public static final class_9139<class_2540, OpenGuiPacket> PACKET_CODEC = class_9139.method_56438(OpenGuiPacket::encode, OpenGuiPacket::decode);

    public void encode(class_2540 buf) {
        buf.method_53002(easelId);
        buf.method_52964(allowed);
        buf.method_52964(edit);
        buf.method_52997(switch (hand) {
            case field_5808 -> 0;
            case field_5810 -> 1;
        });
    }

    public static OpenGuiPacket decode(class_2540 buf) {
        int easelId = buf.readInt();
        boolean allowed = buf.readBoolean();
        boolean edit = buf.readBoolean();
        byte handOrdinal = buf.readByte();
        class_1268 hand = handOrdinal == 1 ? class_1268.field_5810 : class_1268.field_5808;
        return new OpenGuiPacket(easelId, allowed, edit, hand);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }
}

