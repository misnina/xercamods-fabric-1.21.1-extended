package xerca.xercapaint.packets;

import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import xerca.xercapaint.Mod;

public record PictureSendPacket(String canvasId, int version, int[] pixels, boolean sidesActive,
                                int[] sidePixels) implements class_8710 {
    public static final class_8710.class_9154<PictureSendPacket> PACKET_ID = new class_8710.class_9154<>(Mod.id("picture_send"));
    public static final class_9139<class_2540, PictureSendPacket> PACKET_CODEC = class_9139.method_56438(PictureSendPacket::encode, PictureSendPacket::decode);

    public void encode(class_2540 buf) {
        buf.method_10814(canvasId);
        buf.method_53002(version);
        buf.method_10806(pixels);
        buf.method_52964(sidesActive);
        buf.method_10806(sidePixels);
    }

    public static PictureSendPacket decode(class_2540 buf) {
        String canvasId = buf.method_10800(64);
        int version = buf.readInt();
        int[] pixels = buf.method_10799(1024);
        boolean sidesActive = buf.readBoolean();
        // A canvas has at most 2*(32+32) = 128 side pixels.
        int[] sidePixels = buf.method_10799(128);
        return new PictureSendPacket(canvasId, version, pixels, sidesActive, sidePixels);
    }

    public PictureSendPacket {
        pixels = pixels.clone();
        sidePixels = sidePixels.clone();
    }

    @Override
    public int[] pixels() {
        return pixels.clone();
    }

    @Override
    public int[] sidePixels() {
        return sidePixels.clone();
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }
}

