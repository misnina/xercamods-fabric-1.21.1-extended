package xerca.xercapaint.packets;

import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import xerca.xercapaint.Mod;

public record ExportPaintingPacket(String canvasId) implements class_8710 {
    public static final class_8710.class_9154<ExportPaintingPacket> PACKET_ID = new class_8710.class_9154<>(Mod.id("export_painting"));
    public static final class_9139<class_2540, ExportPaintingPacket> PACKET_CODEC = class_9139.method_56438(ExportPaintingPacket::encode, ExportPaintingPacket::decode);

    public void encode(class_2540 buf) {
        buf.method_10814(canvasId);
    }

    public static ExportPaintingPacket decode(class_2540 buf) {
        return new ExportPaintingPacket(buf.method_10800(64));
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }
}

