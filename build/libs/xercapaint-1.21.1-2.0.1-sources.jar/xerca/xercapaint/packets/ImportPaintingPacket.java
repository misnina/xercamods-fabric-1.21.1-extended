package xerca.xercapaint.packets;

import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import xerca.xercapaint.Mod;

public record ImportPaintingPacket(String canvasId) implements class_8710 {
    public static final class_8710.class_9154<ImportPaintingPacket> PACKET_ID = new class_8710.class_9154<>(Mod.id("import_painting"));
    public static final class_9139<class_2540, ImportPaintingPacket> PACKET_CODEC = class_9139.method_56438(ImportPaintingPacket::encode, ImportPaintingPacket::decode);

    public void encode(class_2540 buf) {
        buf.method_10814(canvasId);
    }

    public static ImportPaintingPacket decode(class_2540 buf) {
        String canvasId = buf.method_10800(64);
        return new ImportPaintingPacket(canvasId);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }
}

