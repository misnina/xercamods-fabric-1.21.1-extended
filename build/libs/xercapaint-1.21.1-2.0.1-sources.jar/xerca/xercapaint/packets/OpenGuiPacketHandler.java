package xerca.xercapaint.packets;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import xerca.xercapaint.Mod;
import xerca.xercapaint.client.ModClient;
import xerca.xercapaint.entity.EntityEasel;
import xerca.xercapaint.item.ItemPalette;

public class OpenGuiPacketHandler implements ClientPlayNetworking.PlayPayloadHandler<OpenGuiPacket> {
    private static void processMessage(OpenGuiPacket msg) {
        class_1657 player = class_310.method_1551().field_1724;
        if (player != null) {
            if (msg.allowed()) {
                class_1297 entity = player.method_37908().method_8469(msg.easelId());
                if (entity instanceof EntityEasel easel) {
                    class_1799 itemInHand = player.method_5998(msg.hand());
                    boolean handHoldsPalette = itemInHand.method_7909() instanceof ItemPalette;
                    if (msg.edit()) {
                        if (handHoldsPalette) {
                            ModClient.showCanvasGui(easel, itemInHand);
                        } else {
                            Mod.LOGGER.error("Could not find palette in hand for editing painting");
                        }
                    } else {
                        ModClient.showCanvasGui(easel, class_1799.field_8037);
                    }
                } else {
                    Mod.LOGGER.error("Could not find easel");
                }
            } else {
                player.method_43496(class_2561.method_43471("easel.deny").method_27692(class_124.field_1061));
            }
        }
    }

    @Override
    public void receive(OpenGuiPacket packet, ClientPlayNetworking.Context context) {
        context.client().execute(() -> processMessage(packet));
    }
}
