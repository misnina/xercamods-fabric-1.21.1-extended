package xerca.xercapaint;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import xerca.xercapaint.item.ItemCanvas;
import xerca.xercapaint.item.ItemPalette;
import xerca.xercapaint.item.Items;
import xerca.xercapaint.packets.ImportPaintingPacket;

import java.util.Arrays;

public class CommandImport {
    private CommandImport() {
    }

    private static final String TAG_AUTHOR = "author";
    private static final String TAG_TITLE = "title";
    private static final String TAG_GENERATION = "generation";
    private static final String TAG_CANVAS_ID = "name";

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                class_2170.method_9247("paintimport")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                                .executes(p -> paintImport(p.getSource(), StringArgumentType.getString(p, "name"))))
        );
    }

    private static int paintImport(class_2168 stack, String name) {
        Mod.LOGGER.debug("Paint import called. name: {}", name);

        ImportPaintingPacket pack = new ImportPaintingPacket(name);
        try {
            class_3222 player = stack.method_9207();
            ServerPlayNetworking.send(player, pack);
        } catch (CommandSyntaxException e) {
            Mod.LOGGER.debug("Command executor is not a player", e);
            return 0;
        }

        return 1;
    }

    public static void doImport(class_2487 tag, class_3222 player) {
        // Sanitizing
        if (!tag.method_10573("ct", 1)) {
            notifyBrokenPaintFile(player);
            return;
        }
        if ((tag.method_10573(TAG_AUTHOR, 8) && !tag.method_10573(TAG_TITLE, 8)) ||
                (!tag.method_10573(TAG_AUTHOR, 8) && tag.method_10573(TAG_TITLE, 8))) {
            notifyBrokenPaintFile(player);
            return;
        }
        if (tag.method_10573(TAG_TITLE, 8) && tag.method_10558(TAG_TITLE).length() > 16) {
            tag.method_10582(TAG_TITLE, tag.method_10558(TAG_TITLE).substring(0, 16));
        }
        if (tag.method_10573(TAG_AUTHOR, 8) && tag.method_10558(TAG_AUTHOR).length() > 16) {
            tag.method_10582(TAG_AUTHOR, tag.method_10558(TAG_AUTHOR).substring(0, 16));
        }
        String canvasId;
        if (tag.method_10545(TAG_TITLE)) {
            if (!tag.method_10573(TAG_CANVAS_ID, 8)) {
                notifyBrokenPaintFile(player);
                return;
            }
            canvasId = tag.method_10558(TAG_CANVAS_ID);
            if (!canvasId.matches("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}_\\d+$")) {
                notifyBrokenPaintFile(player);
                return;
            }
            if (!tag.method_10573("v", 3)) {
                tag.method_10569("v", 1);
            }
        } else {
            canvasId = ItemCanvas.generateName(player);
            tag.method_10582(TAG_CANVAS_ID, canvasId);
            tag.method_10569("v", 1);
            tag.method_10551(TAG_GENERATION);
        }

        byte canvasType = tag.method_10571("ct");
        CanvasType importedCanvasType = CanvasType.fromByte(canvasType);
        boolean importedGlass = tag.method_10577("glass");
        tag.method_10551("ct");
        tag.method_10551("glass");
        if (tag.method_10550(TAG_GENERATION) > 0 && tag.method_10550(TAG_GENERATION) < 3) {
            tag.method_10569(TAG_GENERATION, tag.method_10550(TAG_GENERATION) + 1);
        }

        class_1799 itemStack;
        boolean doAddItem = false;
        if (player.method_7337()) {
            itemStack = new class_1799(ItemCanvas.canvasItemFor(importedCanvasType, importedGlass));
            doAddItem = true;
        } else {
            class_1799 mainHand = player.method_6047();
            class_1799 offHand = player.method_6079();

            if (!(mainHand.method_7909() instanceof ItemCanvas heldCanvas) || (mainHand.method_57824(Items.CANVAS_PIXELS) != null || mainHand.method_57824(Items.CANVAS_ID) != null)) {
                player.method_43496(class_2561.method_43471("xercapaint.import.fail.1").method_27692(class_124.field_1061));
                return;
            }
            if (heldCanvas.getCanvasType() != importedCanvasType) {
                class_2561 typeName = ItemCanvas.canvasItemFor(importedCanvasType, importedGlass).method_7864(class_1799.field_8037);
                player.method_43496(class_2561.method_43469("xercapaint.import.fail.2", typeName).method_27692(class_124.field_1061));
                return;
            }
            if (heldCanvas.isGlass() != importedGlass) {
                class_2561 typeName = ItemCanvas.canvasItemFor(importedCanvasType, importedGlass).method_7864(class_1799.field_8037);
                player.method_43496(class_2561.method_43469("xercapaint.import.fail.material", typeName).method_27692(class_124.field_1061));
                return;
            }
            if (!ItemPalette.isFull(offHand)) {
                player.method_43496(class_2561.method_43471("xercapaint.import.fail.3").method_27692(class_124.field_1061));
                return;
            }
            itemStack = mainHand;
        }

        itemStack.method_57379(Items.CANVAS_VERSION, tag.method_10550("v"));
        itemStack.method_57379(Items.CANVAS_ID, canvasId);
        itemStack.method_57379(Items.CANVAS_PIXELS, Arrays.stream(tag.method_10561("pixels")).boxed().toList());
        itemStack.method_57379(Items.CANVAS_GENERATION, tag.method_10550(TAG_GENERATION));
        if (tag.method_10545("sidePixels")) {
            int[] sidePixels = tag.method_10561("sidePixels");
            if (sidePixels.length == CanvasSides.count(importedCanvasType)) {
                itemStack.method_57379(Items.CANVAS_SIDES_ACTIVE, tag.method_10577("sidesActive"));
                itemStack.method_57379(Items.CANVAS_SIDE_PIXELS, Arrays.stream(sidePixels).boxed().toList());
            }
        }
        if (tag.method_10573(TAG_TITLE, 8) && tag.method_10573(TAG_AUTHOR, 8)) {
            itemStack.method_57379(Items.CANVAS_TITLE, tag.method_10558(TAG_TITLE));
            itemStack.method_57379(Items.CANVAS_AUTHOR, tag.method_10558(TAG_AUTHOR));
        }
        ItemCanvas.updateStackSize(itemStack);
        if (doAddItem) {
            player.method_7270(itemStack);
        }

        player.method_43496(class_2561.method_43471("xercapaint.import.success").method_27692(class_124.field_1060));
    }

    private static void notifyBrokenPaintFile(class_3222 player) {
        player.method_43496(class_2561.method_43471("xercapaint.import.fail.5").method_27692(class_124.field_1061));
        Mod.LOGGER.warn("Broken paint file");
    }
}
